# -*- coding: utf-8 -*-
"""CKG-QRIT 在 CMAPSS 上的根因定位。"""

__all__ = ["cmapss_model"]
