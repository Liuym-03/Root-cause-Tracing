
# -*- coding: utf-8 -*-
"""
CMAPSS -> A8 根因定位实验（优化版）

优化点（对齐文献 CMAPSS 实验部分）：
1) 仅保留12个关键时变传感器（去掉恒定/冗余传感器）
2) 三层故障阶段划分：Healthy(RUL>125) / Early(40<RUL≤125) / Late(RUL≤40)
3) 系统级故障检测模块（基于传感器异常比例）
4) 变量级异常比例 η_i（基于健康数据直方图，95%置信区间）
5) 传感器因果图路径追踪（沿 CAUSAL_ADJACENCY 反向推断）
6) 扩展评价指标：Hit@1 / MRR / NDCG@5 / Top@3 / Top@5 / Loc_Acc + 故障检测 Acc/F1
7) 按 (fd, load_state) 建立局部阈值，避免全局固定阈值泛化不足
8) 最终根因分数 = A8融合分数 + 异常比例分数 + 因果路径分数（三路融合）

根因类别：HPC_Early / HPC_Late / Fan_Early / Fan_Late / Mixed_Stress
模式：full（完整A8 Bagging融合）/ simple（线性融合，向后兼容）
"""

from __future__ import annotations

import argparse
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd


# ===================== 全局常量 =====================

RANDOM_SEED = 42

SETTING_COLS = ["setting1", "setting2", "setting3"]

# 12个关键时变传感器（去掉恒定传感器s1,s5,s6,s10,s16,s18,s19及冗余传感器NRf/NRc）
# 参考文献 CMAPSS 实验：去除常数列，再用 Pearson 相关性筛除冗余，保留12个
SELECTED_SENSOR_COLS = [
    "s2",   # T24  - 风扇进口总温
    "s3",   # T30  - LPC 出口总温
    "s4",   # T50  - HPT 出口总温
    "s7",   # P30  - HPC 出口总压
    "s8",   # Nf   - 风扇转速
    "s9",   # Nc   - 核心机转速
    "s11",  # Ps30 - HPC 出口静压
    "s12",  # phi  - 燃烧室进口燃空比
    "s15",  # bpr  - 涵道比
    "s17",  # htBleed - 引气焓
    "s20",  # W31  - HPT 冷却气流量
    "s21",  # W32  - LPT 冷却气流量
]

FEATURE_COLS = SETTING_COLS + SELECTED_SENSOR_COLS

# 故障阶段阈值（文献定义）
FAULT_RUL_THRESHOLD = 125.0   # RUL ≤ 125 视为故障
LATE_RUL_THRESHOLD  = 40.0    # RUL ≤ 40  视为晚期退化

# 传感器物理名称映射（用于可读输出）
SENSOR_NAME_MAP: Dict[str, str] = {
    "s2": "T24", "s3": "T30", "s4": "T50", "s7": "P30",
    "s8": "Nf",  "s9": "Nc",  "s11": "Ps30", "s12": "phi",
    "s15": "bpr", "s17": "htBleed", "s20": "W31", "s21": "W32",
}

# 传感器因果图（稀疏有向无环图，物理先验）
# 根节点：Nf(s8), Nc(s9)；叶节点：T50(s4), bpr(s15)
CAUSAL_ADJACENCY: Dict[str, List[str]] = {
    "s8":  ["s4", "s7", "s11"],   # Nf  -> T50, P30, Ps30
    "s9":  ["s4", "s11", "s12"],  # Nc  -> T50, Ps30, phi
    "s7":  ["s3", "s4"],           # P30 -> T30, T50
    "s11": ["s4", "s15"],          # Ps30 -> T50, bpr
    "s3":  ["s4"],                 # T30 -> T50
    "s17": ["s20", "s21"],         # htBleed -> W31, W32
}
CAUSAL_ROOT_SENSORS = ["s8", "s9"]   # Nf, Nc（根节点）
CAUSAL_LEAF_SENSORS = ["s4", "s15"]  # T50, bpr（叶节点）

# 各根因关联的物理传感器
HPC_SENSORS  = ["s7", "s9", "s11", "s12"]   # P30, Nc, Ps30, phi
FAN_SENSORS  = ["s8", "s15", "s17"]          # Nf, bpr, htBleed
TEMP_SENSORS = ["s2", "s3", "s4"]            # T24, T30, T50（HPC/Fan 共同）

A8_BAGGING_MODELS = 10
RULE_FIELDS = ["temp_indicator", "flow_indicator", "RUL"] + SETTING_COLS
MAX_TUNE_SAMPLES = 2000

ValScoreCache = List[Tuple[str, str, str, Dict[str, float], Dict[str, float], Dict[str, float], Dict[str, float]]]

CAUSES = [
    "HPC_Early",
    "HPC_Late",
    "Fan_Early",
    "Fan_Late",
    "Mixed_Stress",
]


# ===================== 评价指标 =====================

def ranking_metrics(records: List[Dict[str, object]]) -> Dict[str, float]:
    """扩展排序指标：Hit@1 / MRR / NDCG@5 / Top@3 / Top@5 / Loc_Acc"""
    if not records:
        return {"Hit@1": 0.0, "MRR": 0.0, "NDCG@5": 0.0,
                "Top@3": 0.0, "Top@5": 0.0, "Loc_Acc": 0.0}
    hit1  = np.mean([r["rank"][0] == r["true"] for r in records])
    top3  = np.mean([r["true"] in r["rank"][:3] for r in records])
    top5  = np.mean([r["true"] in r["rank"][:5] for r in records])
    rr, ndcg = [], []
    for r in records:
        rank = r["rank"]
        pos = rank.index(r["true"]) + 1
        rr.append(1.0 / pos)
        ndcg.append(1.0 / np.log2(pos + 1.0))
    # Localization Accuracy: Top-3中=1.0, Top-5中=0.5, 否则=0
    loc_acc = float(np.mean([
        1.0 if r["true"] in r["rank"][:3] else (0.5 if r["true"] in r["rank"][:5] else 0.0)
        for r in records
    ]))
    return {
        "Hit@1":   round(float(hit1), 4),
        "MRR":     round(float(np.mean(rr))   if rr   else 0.0, 4),
        "NDCG@5":  round(float(np.mean(ndcg)) if ndcg else 0.0, 4),
        "Top@3":   round(float(top3), 4),
        "Top@5":   round(float(top5), 4),
        "Loc_Acc": round(loc_acc, 4),
    }


def objective_score(metric: str, metrics: Dict[str, float]) -> float:
    if metric == "hit1":
        return float(metrics["Hit@1"])
    if metric == "mrr":
        return float(metrics["MRR"])
    return 0.8 * float(metrics["Hit@1"]) + 0.2 * float(metrics["MRR"])


def normalize_scores(score_dict: Dict[str, float]) -> Dict[str, float]:
    arr = np.array([score_dict[c] for c in CAUSES], dtype=float)
    arr = np.maximum(arr, 1e-12)
    arr = arr / (arr.sum() + 1e-12)
    return {c: float(v) for c, v in zip(CAUSES, arr)}


def rank_causes(score_dict: Dict[str, float]) -> List[str]:
    return sorted(CAUSES, key=lambda c: score_dict[c], reverse=True)


# ===================== 故障检测评估 =====================

def evaluate_fault_detection_metrics(df: pd.DataFrame, hist_profile: Dict[str, Dict[str, float]],
                                      anomaly_threshold: float = 0.25) -> Dict[str, float]:
    """
    系统级故障检测评估。
    用各传感器相对健康分布的 z-score 超标比例判断是否故障，
    与 RUL ≤ 125 的真实标签对比，计算 Acc / F1 / Precision / Recall。
    """
    y_true, y_pred = [], []
    for _, row in df.iterrows():
        true_fault = int(float(row["RUL"]) <= FAULT_RUL_THRESHOLD)
        anomaly_cnt = 0
        for s in SELECTED_SENSOR_COLS:
            val = float(row[s])
            p = hist_profile.get(s, {})
            if p:
                z = abs(val - p["mean"]) / (p["std"] + 1e-9)
                if z > 2.0:
                    anomaly_cnt += 1
        pred_fault = int(anomaly_cnt / len(SELECTED_SENSOR_COLS) >= anomaly_threshold)
        y_true.append(true_fault)
        y_pred.append(pred_fault)
    yt = np.array(y_true, dtype=int)
    yp = np.array(y_pred, dtype=int)
    tp = int(np.sum((yt == 1) & (yp == 1)))
    tn = int(np.sum((yt == 0) & (yp == 0)))
    fp = int(np.sum((yt == 0) & (yp == 1)))
    fn = int(np.sum((yt == 1) & (yp == 0)))
    acc  = (tp + tn) / max(tp + tn + fp + fn, 1)
    prec = tp / max(tp + fp, 1)
    rec  = tp / max(tp + fn, 1)
    f1   = 2 * prec * rec / max(prec + rec, 1e-9)
    return {
        "FaultDetect_Acc":       round(float(acc),  4),
        "FaultDetect_F1":        round(float(f1),   4),
        "FaultDetect_Precision": round(float(prec), 4),
        "FaultDetect_Recall":    round(float(rec),  4),
    }


# ===================== 直方图异常监测 =====================

def build_histogram_profile(
    train_df: pd.DataFrame,
    q_low: float = 0.025,
    q_high: float = 0.975,
) -> Dict[str, Dict[str, float]]:
    """
    基于健康训练样本（RUL > FAULT_RUL_THRESHOLD）建立每个传感器的分位数画像。
    默认采用 95% 置信区间（q_low=0.025, q_high=0.975）。
    若健康样本不足，回退到全部训练样本。
    """
    healthy = train_df[train_df["RUL"] > FAULT_RUL_THRESHOLD]
    if len(healthy) < 50:
        healthy = train_df
    hist: Dict[str, Dict[str, float]] = {}
    for s in SELECTED_SENSOR_COLS:
        vals = healthy[s].dropna().values.astype(float)
        hist[s] = {
            "q_low":  float(np.quantile(vals, q_low)),
            "q_high": float(np.quantile(vals, q_high)),
            "mean":   float(np.mean(vals)),
            "std":    float(max(np.std(vals), 1e-6)),
        }
    return hist


def compute_anomaly_ratio_single(
    sample: pd.Series,
    hist_profile: Dict[str, Dict[str, float]],
) -> Dict[str, float]:
    """
    对单个样本，计算每个传感器是否超出健康分布的 95% 置信区间。
    返回值为 {sensor: 0.0 或 1.0}（单样本异常比例退化为0/1指示）。
    """
    ratios: Dict[str, float] = {}
    for s in SELECTED_SENSOR_COLS:
        val = float(sample[s])
        p   = hist_profile.get(s, {})
        if p:
            is_abnormal = float(val < p["q_low"] or val > p["q_high"])
        else:
            is_abnormal = 0.0
        ratios[s] = is_abnormal
    return ratios


def map_anomaly_to_cause_score(anomaly_ratios: Dict[str, float]) -> Dict[str, float]:
    """将传感器异常指示映射为根因候选分数（基于物理关联）。"""
    hpc_anom  = float(np.mean([anomaly_ratios.get(s, 0.0) for s in HPC_SENSORS]))
    fan_anom  = float(np.mean([anomaly_ratios.get(s, 0.0) for s in FAN_SENSORS]))
    temp_anom = float(np.mean([anomaly_ratios.get(s, 0.0) for s in TEMP_SENSORS]))

    # 温度异常对 HPC 和 Fan 都有贡献（温度是共同效应）
    hpc_score = hpc_anom + 0.4 * temp_anom
    fan_score = fan_anom + 0.4 * temp_anom
    mix_score = min(hpc_anom + fan_anom + temp_anom, 1.0)

    return {
        "HPC_Early":    max(0.05, hpc_score),
        "HPC_Late":     max(0.05, hpc_score),
        "Fan_Early":    max(0.05, fan_score),
        "Fan_Late":     max(0.05, fan_score),
        "Mixed_Stress": max(0.05, mix_score),
    }


# ===================== 因果路径追踪 =====================

def compute_causal_path_score(anomaly_ratios: Dict[str, float]) -> Dict[str, float]:
    """
    沿传感器因果图反向追踪异常传播，估计根因支持度。
    逻辑：
      - 正向：根节点异常 → 下游节点也可能异常（传播系数 0.8）
      - 反向：叶节点异常 → 反推上游根节点可能性（传播系数 0.6）
    """
    path_score: Dict[str, float] = {s: anomaly_ratios.get(s, 0.0) for s in SELECTED_SENSOR_COLS}

    # 正向传播：源节点异常 → 目标节点传播
    for src, targets in CAUSAL_ADJACENCY.items():
        src_anom = anomaly_ratios.get(src, 0.0)
        for tgt in targets:
            path_score[tgt] = max(path_score.get(tgt, 0.0), src_anom * 0.8)

    # 反向推断：叶节点异常 → 根节点可能性上升
    for src, targets in CAUSAL_ADJACENCY.items():
        for tgt in targets:
            tgt_anom = anomaly_ratios.get(tgt, 0.0)
            path_score[src] = max(path_score.get(src, 0.0), tgt_anom * 0.6)

    hpc_path = float(np.mean([path_score.get(s, 0.0) for s in HPC_SENSORS]))
    fan_path = float(np.mean([path_score.get(s, 0.0) for s in FAN_SENSORS]))

    return {
        "HPC_Early":    max(0.05, hpc_path),
        "HPC_Late":     max(0.05, hpc_path),
        "Fan_Early":    max(0.05, fan_path),
        "Fan_Late":     max(0.05, fan_path),
        "Mixed_Stress": max(0.05, (hpc_path + fan_path) / 2.0),
    }


def score_anomaly_combined(
    sample: pd.Series,
    hist_profile: Dict[str, Dict[str, float]],
    rul: Optional[float] = None,
) -> Dict[str, float]:
    """
    融合变量异常比例分数 + 因果路径分数，并用 RUL 阶段区分 Early/Late。
    final = 0.5 * anomaly_score + 0.5 * causal_path_score
    """
    anomaly_ratios   = compute_anomaly_ratio_single(sample, hist_profile)
    anom_cause_score = map_anomaly_to_cause_score(anomaly_ratios)
    path_score       = compute_causal_path_score(anomaly_ratios)

    combined: Dict[str, float] = {}
    for c in CAUSES:
        combined[c] = 0.5 * anom_cause_score[c] + 0.5 * path_score[c]

    # 用 RUL 阶段将 Early/Late 加权区分
    if rul is not None:
        late_w  = float(1.0 / (1.0 + np.exp(-(LATE_RUL_THRESHOLD - rul) / 8.0)))
        early_w = 1.0 - late_w
        for prefix in ("HPC", "Fan"):
            combined[f"{prefix}_Late"]  = combined[f"{prefix}_Late"]  * late_w  + combined[f"{prefix}_Early"] * (1 - late_w) * 0.5
            combined[f"{prefix}_Early"] = combined[f"{prefix}_Early"] * early_w + combined[f"{prefix}_Late"]  * (1 - early_w) * 0.5

    return normalize_scores(combined)


# ===================== 统计模型 =====================

def build_baseline_model(train_df: pd.DataFrame) -> Tuple[Dict[str, np.ndarray], Dict[str, np.ndarray]]:
    means: Dict[str, np.ndarray] = {}
    stds:  Dict[str, np.ndarray] = {}
    for c in CAUSES:
        sub = train_df[train_df["true_cause"] == c]
        if sub.empty:
            sub = train_df
        means[c] = sub[FEATURE_COLS].mean().values.astype(float)
        stds[c]  = sub[FEATURE_COLS].std().fillna(1.0).replace(0, 1.0).values.astype(float)
    return means, stds


def score_baseline(sample: pd.Series, means: Dict[str, np.ndarray], stds: Dict[str, np.ndarray]) -> Dict[str, float]:
    x = sample[FEATURE_COLS].values.astype(float)
    scores = {}
    for c in CAUSES:
        z = np.abs((x - means[c]) / (stds[c] + 1e-9))
        scores[c] = float(np.exp(-np.mean(z)))
    return scores


def build_kg_priors(train_df: pd.DataFrame) -> Dict[Tuple[str, str], Dict[str, float]]:
    priors: Dict[Tuple[str, str], Dict[str, float]] = {}
    for fd in sorted(train_df["fd"].unique()):
        for load_state in ["high", "normal"]:
            key = (fd, load_state)
            sub = train_df[(train_df["fd"] == fd) & (train_df["load_state"] == load_state)]
            if sub.empty:
                sub = train_df[train_df["fd"] == fd]
            n, k = len(sub), len(CAUSES)
            d = {}
            for c in CAUSES:
                cnt  = int((sub["true_cause"] == c).sum())
                d[c] = (cnt + 1.0) / (n + k)
            priors[key] = d
    return priors


def score_kg(sample: pd.Series, priors: Dict[Tuple[str, str], Dict[str, float]]) -> Dict[str, float]:
    key = (sample["fd"], sample["load_state"])
    if key in priors:
        return priors[key].copy()
    return next(iter(priors.values())).copy()


def build_causal_tables(
    train_df: pd.DataFrame,
) -> Tuple[Dict[str, Dict[str, float]], Dict[str, Dict[Tuple[str, str], float]]]:
    pz_fd: Dict[str, Dict[str, float]] = {}
    for fd in sorted(train_df["fd"].unique()):
        sub_fd = train_df[train_df["fd"] == fd]
        d = sub_fd["load_state"].value_counts(normalize=True).to_dict()
        d.setdefault("high", 0.5)
        d.setdefault("normal", 0.5)
        pz_fd[fd] = d

    py_x_z: Dict[str, Dict[Tuple[str, str], float]] = {c: {} for c in CAUSES}
    for c in CAUSES:
        for fd in sorted(train_df["fd"].unique()):
            for z in ["high", "normal"]:
                sub  = train_df[(train_df["fd"] == fd) & (train_df["load_state"] == z)]
                if sub.empty:
                    sub = train_df[train_df["fd"] == fd]
                conf  = sub["label_confidence"] if "label_confidence" in sub.columns else pd.Series(np.ones(len(sub)))
                denom = float(conf.sum() + len(CAUSES))
                num   = float(conf[sub["true_cause"] == c].sum() + 1.0)
                py_x_z[c][(fd, z)] = num / max(denom, 1e-9)
    return pz_fd, py_x_z


def score_causal_do(
    sample: pd.Series,
    pz_fd: Dict[str, Dict[str, float]],
    py_x_z: Dict[str, Dict[Tuple[str, str], float]],
) -> Dict[str, float]:
    fd = sample["fd"]
    pz = pz_fd.get(fd, {"high": 0.5, "normal": 0.5})
    out = {}
    for c in CAUSES:
        ph = py_x_z[c].get((fd, "high"),   1.0 / len(CAUSES))
        pn = py_x_z[c].get((fd, "normal"), 1.0 / len(CAUSES))
        out[c] = ph * pz["high"] + pn * pz["normal"]
    return out


# ===================== 图证据画像（支持局部阈值） =====================

def build_graph_profile(train_df: pd.DataFrame) -> Dict[str, Any]:
    """
    建立全局 + 局部（per-fd, per-load_state）的传感器指标分位数画像。
    局部阈值存于 result["local"][(fd, load_state)]，用于按工况细化规则分数。
    """
    ti = train_df["s2"] + train_df["s3"] + train_df["s4"]
    fi = train_df["s11"] + train_df["s12"] + train_df["s15"]
    result: Dict[str, Any] = {
        "temp_q60":  float(ti.quantile(0.60)),
        "flow_q60":  float(fi.quantile(0.60)),
        "local": {},
    }
    for fd in sorted(train_df["fd"].unique()):
        for load_state in ["high", "normal"]:
            sub = train_df[(train_df["fd"] == fd) & (train_df["load_state"] == load_state)]
            if len(sub) >= 10:
                sub_ti = sub["s2"] + sub["s3"] + sub["s4"]
                sub_fi = sub["s11"] + sub["s12"] + sub["s15"]
                result["local"][(fd, load_state)] = {
                    "temp_q60": float(sub_ti.quantile(0.60)),
                    "flow_q60": float(sub_fi.quantile(0.60)),
                }
    return result


def score_graph(sample: pd.Series, graph_profile: Dict[str, Any]) -> Dict[str, float]:
    """图证据分数：将变量症状映射为根因路径支持度。"""
    local = graph_profile.get("local", {}).get(
        (str(sample["fd"]), str(sample["load_state"])), {}
    )
    temp_q60 = local.get("temp_q60", graph_profile["temp_q60"])
    flow_q60 = local.get("flow_q60", graph_profile["flow_q60"])

    temp_indicator = float(sample["s2"] + sample["s3"] + sample["s4"])
    flow_indicator = float(sample["s11"] + sample["s12"] + sample["s15"])
    high_temp = temp_indicator >= temp_q60
    high_flow = flow_indicator >= flow_q60
    high_load = sample["load_state"] == "high"
    late = float(sample["RUL"]) <= LATE_RUL_THRESHOLD
    fd   = str(sample["fd"])

    s = {c: 0.2 for c in CAUSES}
    if high_flow:
        s["HPC_Late" if late else "HPC_Early"] += 1.0
    if high_temp:
        s["Fan_Late" if late else "Fan_Early"] += 1.0
    if high_temp and high_flow and high_load:
        s["Mixed_Stress"] += 1.4
    if fd in ("FD001", "FD002"):
        s["HPC_Late" if late else "HPC_Early"] += 0.5
        s["Fan_Late"]    *= 0.6
        s["Fan_Early"]   *= 0.6
        s["Mixed_Stress"] *= 0.5
    return s


def build_rule_profile(train_df: pd.DataFrame) -> Dict[str, Dict[str, float]]:
    """从训练集学习机理启发统计画像（不直接使用 true_cause 列做推理）。"""
    tmp = train_df.copy()
    tmp["temp_indicator"] = tmp["s2"] + tmp["s3"] + tmp["s4"]
    tmp["flow_indicator"] = tmp["s11"] + tmp["s12"] + tmp["s15"]
    profile: Dict[str, Dict[str, float]] = {}
    for cause in CAUSES:
        sub = tmp[tmp["true_cause"] == cause]
        if sub.empty:
            sub = tmp
        profile[cause] = {}
        for f in RULE_FIELDS:
            profile[cause][f"{f}_mean"] = float(sub[f].mean())
            profile[cause][f"{f}_std"]  = float(max(sub[f].std(), 1e-6))
    return profile


def score_rule_profile(
    sample: pd.Series,
    profile: Dict[str, Dict[str, float]],
    graph_profile: Dict[str, Any],
) -> Dict[str, float]:
    """
    CMAPSS 机理规则分数：温度/流量/RUL/工况 → HPC/Fan/Mixed 软证据。
    使用局部 (fd, load_state) 分位数阈值（若存在）替代全局阈值。
    """
    del profile  # 推理侧用显式机理规则
    local = graph_profile.get("local", {}).get(
        (str(sample["fd"]), str(sample["load_state"])), {}
    )
    temp_q60 = local.get("temp_q60", graph_profile["temp_q60"])
    flow_q60 = local.get("flow_q60", graph_profile["flow_q60"])

    temp_indicator = float(sample["s2"] + sample["s3"] + sample["s4"])
    flow_indicator = float(sample["s11"] + sample["s12"] + sample["s15"])
    rul       = float(sample["RUL"])
    high_load = sample["load_state"] == "high"
    fd        = str(sample["fd"])

    temp_margin = max(temp_indicator - temp_q60, 0.0)
    flow_margin = max(flow_indicator - flow_q60, 0.0)
    hpc_flow  = float(np.exp(-flow_margin / (flow_q60 * 0.15 + 1e-6)))
    fan_temp  = float(np.exp(-temp_margin / (temp_q60 * 0.15 + 1e-6)))
    late_score  = float(1.0 / (1.0 + np.exp(-(LATE_RUL_THRESHOLD - rul) / 8.0)))
    early_score = 1.0 - late_score
    mixed_score = fan_temp * hpc_flow * (1.2 if high_load else 0.6)

    scores = {
        "HPC_Early":    max(0.15, hpc_flow * early_score),
        "HPC_Late":     max(0.15, hpc_flow * late_score),
        "Fan_Early":    max(0.15, fan_temp * early_score),
        "Fan_Late":     max(0.15, fan_temp * late_score),
        "Mixed_Stress": max(0.15, mixed_score),
    }
    if fd in ("FD001", "FD002"):
        scores["Fan_Early"]   *= 0.35
        scores["Fan_Late"]    *= 0.35
        scores["Mixed_Stress"] *= 0.4
        scores["HPC_Early"]   *= 1.2
        scores["HPC_Late"]    *= 1.2
    return scores


# ===================== 完整 A8 融合 =====================

def build_val_score_cache(
    val_df: pd.DataFrame,
    means: Dict[str, np.ndarray],
    stds:  Dict[str, np.ndarray],
    priors: Dict[Tuple[str, str], Dict[str, float]],
    pz_fd: Dict[str, Dict[str, float]],
    py_x_z: Dict[str, Dict[Tuple[str, str], float]],
    rule_profile: Dict[str, Dict[str, float]],
    graph_profile: Dict[str, Any],
) -> ValScoreCache:
    cache: ValScoreCache = []
    for _, sample in val_df.iterrows():
        cache.append((
            str(sample["true_cause"]),
            str(sample["fd"]),
            str(sample["load_state"]),
            normalize_scores(score_baseline(sample, means, stds)),
            normalize_scores(score_kg(sample, priors)),
            normalize_scores(score_causal_do(sample, pz_fd, py_x_z)),
            normalize_scores(score_rule_profile(sample, rule_profile, graph_profile)),
        ))
    return cache


def _cache_to_mats(
    cache: ValScoreCache,
) -> Tuple[List[str], List[str], List[str], np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    n = len(cache)
    y_true = [row[0] for row in cache]
    fds    = [row[1] for row in cache]
    loads  = [row[2] for row in cache]
    base_mat   = np.zeros((n, len(CAUSES)), dtype=float)
    kg_mat     = np.zeros((n, len(CAUSES)), dtype=float)
    causal_mat = np.zeros((n, len(CAUSES)), dtype=float)
    rule_mat   = np.zeros((n, len(CAUSES)), dtype=float)
    for i, (_, _, _, base, kg, causal, rule) in enumerate(cache):
        for j, c in enumerate(CAUSES):
            base_mat[i, j]   = base[c]
            kg_mat[i, j]     = kg[c]
            causal_mat[i, j] = causal[c]
            rule_mat[i, j]   = rule[c]
    return y_true, fds, loads, base_mat, kg_mat, causal_mat, rule_mat


def _metrics_from_prob_mat(prob_mat: np.ndarray, y_true: List[str]) -> Dict[str, float]:
    cause_idx = {c: i for i, c in enumerate(CAUSES)}
    pred_idx  = np.argmax(prob_mat, axis=1)
    hit1  = float(np.mean([CAUSES[pred_idx[i]] == y_true[i] for i in range(len(y_true))]))
    top3  = float(np.mean([y_true[i] in [CAUSES[j] for j in np.argsort(-prob_mat[i])[:3]] for i in range(len(y_true))]))
    rr, ndcg = [], []
    for i in range(len(y_true)):
        rank   = np.argsort(-prob_mat[i])
        true_j = cause_idx[y_true[i]]
        pos    = int(np.where(rank == true_j)[0][0]) + 1
        rr.append(1.0 / pos)
        ndcg.append(1.0 / np.log2(pos + 1.0))
    return {
        "Hit@1":  round(hit1, 4),
        "MRR":    round(float(np.mean(rr)),   4),
        "NDCG@5": round(float(np.mean(ndcg)), 4),
        "Top@3":  round(top3, 4),
    }


def _normalize_rows(mat: np.ndarray) -> np.ndarray:
    mat = np.maximum(mat, 1e-12)
    return mat / (mat.sum(axis=1, keepdims=True) + 1e-15)


def _apply_temp_rows(mat: np.ndarray, temperature: float) -> np.ndarray:
    temperature = max(float(temperature), 1e-6)
    mat = _normalize_rows(mat)
    mat = mat ** (1.0 / temperature)
    return _normalize_rows(mat)


def _fuse_log_opinion_rows(
    base_mat: np.ndarray,
    kg_mat: np.ndarray,
    causal_mat: np.ndarray,
    weights: Dict[str, float],
    temps: Dict[str, float],
    gamma: float,
) -> np.ndarray:
    b  = _apply_temp_rows(base_mat,   temps.get("baseline", 1.0))
    k  = _apply_temp_rows(kg_mat,     temps.get("kg", 1.0))
    c  = _apply_temp_rows(causal_mat, temps.get("causal", 1.0))
    wb, wk, wc = weights.get("baseline", 0.0), weights.get("kg", 0.0), weights.get("causal", 0.0)
    fused = np.exp(wb * np.log(b + 1e-12) + wk * np.log(k + 1e-12) + wc * np.log(c + 1e-12))
    fused = _normalize_rows(fused)
    if gamma != 1.0:
        fused = _normalize_rows(np.maximum(fused, 1e-12) ** float(gamma))
    return fused


def learn_blend_weights_grid(cache: ValScoreCache, step: float = 0.05) -> Dict[str, float]:
    y_true, _, _, base_mat, kg_mat, causal_mat, _ = _cache_to_mats(cache)
    grid = np.arange(0, 1 + 1e-9, step)
    best = {"baseline": 1.0, "kg": 0.0, "causal": 0.0}
    best_mrr = -1.0
    for wb in grid:
        for wk in grid:
            wc = 1.0 - wb - wk
            if wc < -1e-9:
                continue
            wc = max(0.0, float(wc))
            fused = _normalize_rows(wb * base_mat + wk * kg_mat + wc * causal_mat)
            cur_mrr = _metrics_from_prob_mat(fused, y_true)["MRR"]
            if cur_mrr > best_mrr:
                best_mrr = cur_mrr
                best = {"baseline": float(wb), "kg": float(wk), "causal": float(wc)}
    return best


def apply_temperature(prob_dict: Dict[str, float], temperature: float) -> Dict[str, float]:
    temperature = max(float(temperature), 1e-6)
    arr = np.array([prob_dict[c] for c in CAUSES], dtype=float)
    arr = np.maximum(arr, 1e-12)
    arr = arr / arr.sum()
    arr = arr ** (1.0 / temperature)
    arr = arr / (arr.sum() + 1e-12)
    return {c: float(v) for c, v in zip(CAUSES, arr)}


def fuse_log_opinion_pool(
    base: Dict[str, float],
    kg: Dict[str, float],
    causal: Dict[str, float],
    weights: Dict[str, float],
    temps: Dict[str, float],
    gamma: float = 1.0,
) -> Dict[str, float]:
    base_t   = apply_temperature(base,   temps.get("baseline", 1.0))
    kg_t     = apply_temperature(kg,     temps.get("kg", 1.0))
    causal_t = apply_temperature(causal, temps.get("causal", 1.0))
    fused = {}
    for c in CAUSES:
        val = (
            weights.get("baseline", 0.0) * np.log(base_t[c]   + 1e-12)
            + weights.get("kg", 0.0)     * np.log(kg_t[c]     + 1e-12)
            + weights.get("causal", 0.0) * np.log(causal_t[c] + 1e-12)
        )
        fused[c] = float(np.exp(val))
    fused = normalize_scores(fused)
    if gamma != 1.0:
        arr = np.array([fused[c] for c in CAUSES], dtype=float)
        arr = np.maximum(arr, 1e-12) ** float(gamma)
        arr = arr / (arr.sum() + 1e-12)
        fused = {c: float(v) for c, v in zip(CAUSES, arr)}
    return fused


def tune_a8_fusion_params(
    cache: ValScoreCache,
    learned_weights: Dict[str, float],
    temp_grid: Optional[List[float]] = None,
    gamma_grid: Optional[List[float]] = None,
    rule_alpha_grid: Optional[List[float]] = None,
) -> Tuple[Dict[str, float], float, float]:
    y_true, _, _, base_mat, kg_mat, causal_mat, rule_mat = _cache_to_mats(cache)
    temp_grid       = temp_grid       or [0.7, 0.85, 1.0, 1.15]
    gamma_grid      = gamma_grid      or [1.0, 1.2, 1.4, 1.6]
    rule_alpha_grid = rule_alpha_grid or [0.0, 0.1, 0.2, 0.3, 0.4]
    best_temps     = {"baseline": 1.0, "kg": 1.0, "causal": 1.0}
    best_gamma     = 1.0
    best_rule_alpha = 0.0
    best_hit1      = -1.0
    best_mrr       = -1.0
    for rule_alpha in rule_alpha_grid:
        base_aug = _normalize_rows((1.0 - rule_alpha) * base_mat + rule_alpha * rule_mat)
        for tb in temp_grid:
            for tk in temp_grid:
                for tc in temp_grid:
                    for gamma in gamma_grid:
                        fused  = _fuse_log_opinion_rows(
                            base_aug, kg_mat, causal_mat, learned_weights,
                            {"baseline": tb, "kg": tk, "causal": tc}, gamma,
                        )
                        metric = _metrics_from_prob_mat(fused, y_true)
                        if (metric["Hit@1"] > best_hit1) or (
                            metric["Hit@1"] == best_hit1 and metric["MRR"] > best_mrr
                        ):
                            best_hit1, best_mrr = metric["Hit@1"], metric["MRR"]
                            best_temps     = {"baseline": tb, "kg": tk, "causal": tc}
                            best_gamma     = gamma
                            best_rule_alpha = rule_alpha
    return best_temps, best_gamma, best_rule_alpha


def learn_context_expert_weights(
    cache: ValScoreCache,
    step: float = 0.1,
) -> Dict[Tuple[str, str], Dict[str, float]]:
    context_weights: Dict[Tuple[str, str], Dict[str, float]] = {}
    contexts = sorted({(row[1], row[2]) for row in cache})
    for ctx in contexts:
        sub_cache = [row for row in cache if (row[1], row[2]) == ctx]
        if len(sub_cache) < 8:
            continue
        context_weights[ctx] = learn_blend_weights_grid(sub_cache, step=step)
    return context_weights


def tune_a8_context_alpha(
    cache: ValScoreCache,
    global_weights: Dict[str, float],
    context_weights: Dict[Tuple[str, str], Dict[str, float]],
    temps: Dict[str, float],
    gamma: float,
    rule_alpha: float,
) -> float:
    y_true, _, _, base_mat, kg_mat, causal_mat, rule_mat = _cache_to_mats(cache)
    base_aug = _normalize_rows((1.0 - rule_alpha) * base_mat + rule_alpha * rule_mat)
    global_scores = _fuse_log_opinion_rows(base_aug, kg_mat, causal_mat, global_weights, temps, gamma)
    alpha_grid = [0.0, 0.15, 0.3, 0.5, 0.7, 0.85, 1.0]
    best_alpha = 1.0
    best_hit1  = -1.0
    best_mrr   = -1.0
    for alpha in alpha_grid:
        merged = np.zeros_like(global_scores)
        for i, row in enumerate(cache):
            ctx_w     = context_weights.get((row[1], row[2]), global_weights)
            ctx_score = _fuse_log_opinion_rows(
                base_aug[i:i+1], kg_mat[i:i+1], causal_mat[i:i+1], ctx_w, temps, gamma
            )[0]
            merged[i] = alpha * global_scores[i] + (1.0 - alpha) * ctx_score
        merged = _normalize_rows(merged)
        metric = _metrics_from_prob_mat(merged, y_true)
        if (metric["Hit@1"] > best_hit1) or (metric["Hit@1"] == best_hit1 and metric["MRR"] > best_mrr):
            best_hit1, best_mrr = metric["Hit@1"], metric["MRR"]
            best_alpha = alpha
    return best_alpha


def tune_fd_specific_a8_params(
    cache: ValScoreCache,
    learned_weights: Dict[str, float],
    context_weights: Dict[Tuple[str, str], Dict[str, float]],
    base_temps: Dict[str, float],
    base_gamma: float,
    base_rule_alpha: float,
    base_alpha: float,
) -> Dict[str, Dict[str, float]]:
    fd_params: Dict[str, Dict[str, float]] = {}
    fds = sorted({row[1] for row in cache})
    for fd in fds:
        sub_cache = [row for row in cache if row[1] == fd]
        if len(sub_cache) < 8:
            continue
        y_true, _, _, base_mat, kg_mat, causal_mat, rule_mat = _cache_to_mats(sub_cache)
        best = {
            "tb": base_temps["baseline"], "tk": base_temps["kg"], "tc": base_temps["causal"],
            "gamma": base_gamma, "rule_alpha": base_rule_alpha, "alpha": base_alpha,
        }
        best_hit1 = best_mrr = -1.0
        scale_grid = [0.85, 1.0, 1.15]
        gamma_grid = sorted({max(1.0, base_gamma - 0.2), base_gamma, min(1.6, base_gamma + 0.2)})
        rule_grid  = sorted({max(0.0, base_rule_alpha - 0.1), base_rule_alpha, min(0.6, base_rule_alpha + 0.1)})
        alpha_grid = sorted({0.0, 0.3, base_alpha, 0.6, 1.0})
        for sb in scale_grid:
            for sk in scale_grid:
                for sc in scale_grid:
                    for gamma in gamma_grid:
                        for rule_alpha in rule_grid:
                            base_aug = _normalize_rows((1.0 - rule_alpha) * base_mat + rule_alpha * rule_mat)
                            for alpha in alpha_grid:
                                temps = {
                                    "baseline": max(0.5, min(1.3, base_temps["baseline"] * sb)),
                                    "kg":       max(0.5, min(1.3, base_temps["kg"]       * sk)),
                                    "causal":   max(0.5, min(1.3, base_temps["causal"]   * sc)),
                                }
                                global_scores = _fuse_log_opinion_rows(
                                    base_aug, kg_mat, causal_mat, learned_weights, temps, gamma
                                )
                                merged = np.zeros_like(global_scores)
                                for i, row in enumerate(sub_cache):
                                    ctx_w = context_weights.get((row[1], row[2]), learned_weights)
                                    ctx_score = _fuse_log_opinion_rows(
                                        base_aug[i:i+1], kg_mat[i:i+1], causal_mat[i:i+1], ctx_w, temps, gamma
                                    )[0]
                                    merged[i] = alpha * global_scores[i] + (1.0 - alpha) * ctx_score
                                metric = _metrics_from_prob_mat(_normalize_rows(merged), y_true)
                                if (metric["Hit@1"] > best_hit1) or (
                                    metric["Hit@1"] == best_hit1 and metric["MRR"] > best_mrr
                                ):
                                    best_hit1, best_mrr = metric["Hit@1"], metric["MRR"]
                                    best = {
                                        "tb": temps["baseline"], "tk": temps["kg"], "tc": temps["causal"],
                                        "gamma": gamma, "rule_alpha": rule_alpha, "alpha": alpha,
                                    }
        fd_params[fd] = best
    return fd_params


def train_a8_artifact(
    train_df: pd.DataFrame,
    val_df: pd.DataFrame,
    quick_mode: bool = False,
    max_tune_samples: int = MAX_TUNE_SAMPLES,
) -> Dict[str, object]:
    means, stds  = build_baseline_model(train_df)
    priors       = build_kg_priors(train_df)
    pz_fd, py_x_z = build_causal_tables(train_df)
    graph_profile = build_graph_profile(train_df)
    rule_profile  = build_rule_profile(train_df)
    hist_profile  = build_histogram_profile(train_df)
    tune_df = val_df
    cache   = build_val_score_cache(tune_df, means, stds, priors, pz_fd, py_x_z, rule_profile, graph_profile)
    step    = 0.05 if quick_mode else 0.02
    learned_weights = learn_blend_weights_grid(cache, step=step)
    a8_temps, a8_gamma, a8_rule_alpha = tune_a8_fusion_params(
        cache, learned_weights,
        temp_grid       = [0.8, 1.0, 1.15]       if quick_mode else None,
        gamma_grid      = [1.0, 1.2]              if quick_mode else None,
        rule_alpha_grid = [0.0, 0.1, 0.2, 0.3]   if quick_mode else None,
    )
    context_weights = learn_context_expert_weights(cache, step=0.1)
    a8_alpha        = tune_a8_context_alpha(cache, learned_weights, context_weights, a8_temps, a8_gamma, a8_rule_alpha)
    fd_specific     = tune_fd_specific_a8_params(
        cache, learned_weights, context_weights, a8_temps, a8_gamma, a8_rule_alpha, a8_alpha
    )
    return {
        "means": means, "stds": stds,
        "priors": priors, "pz_fd": pz_fd, "py_x_z": py_x_z,
        "graph_profile": graph_profile, "rule_profile": rule_profile,
        "hist_profile": hist_profile,
        "learned_weights": learned_weights,
        "a8_temps": a8_temps, "a8_gamma": a8_gamma, "a8_rule_alpha": a8_rule_alpha,
        "context_weights": context_weights, "a8_alpha": a8_alpha, "fd_specific": fd_specific,
    }


def predict_a8_score(
    sample: pd.Series,
    artifact: Dict[str, object],
    anomaly_weight: float = 0.15,
) -> Dict[str, float]:
    """
    A8 根因分数预测（含异常比例 + 因果路径后验调整）。
    final_score = (1 - anomaly_weight) * A8_model_score + anomaly_weight * anomaly_combined_score
    """
    means          = artifact["means"]
    stds           = artifact["stds"]
    priors         = artifact["priors"]
    pz_fd          = artifact["pz_fd"]
    py_x_z         = artifact["py_x_z"]
    graph_profile  = artifact["graph_profile"]
    rule_profile   = artifact["rule_profile"]
    hist_profile   = artifact["hist_profile"]
    learned_weights = artifact["learned_weights"]
    context_weights = artifact["context_weights"]
    params = artifact["fd_specific"].get(str(sample["fd"]))
    if params is None:
        temps      = artifact["a8_temps"]
        gamma      = artifact["a8_gamma"]
        rule_alpha = artifact["a8_rule_alpha"]
        alpha      = artifact["a8_alpha"]
    else:
        temps      = {"baseline": params["tb"], "kg": params["tk"], "causal": params["tc"]}
        gamma      = params["gamma"]
        rule_alpha = params["rule_alpha"]
        alpha      = params["alpha"]

    base     = normalize_scores(score_baseline(sample, means, stds))
    rule     = normalize_scores(score_rule_profile(sample, rule_profile, graph_profile))
    base_aug = {c: (1.0 - rule_alpha) * base[c] + rule_alpha * rule[c] for c in CAUSES}
    base_aug = normalize_scores(base_aug)
    kg       = normalize_scores(score_kg(sample, priors))
    causal   = normalize_scores(score_causal_do(sample, pz_fd, py_x_z))

    global_scores  = fuse_log_opinion_pool(base_aug, kg, causal, learned_weights, temps, gamma=gamma)
    ctx_key        = (str(sample["fd"]), str(sample["load_state"]))
    ctx_w          = context_weights.get(ctx_key, learned_weights)
    context_scores = fuse_log_opinion_pool(base_aug, kg, causal, ctx_w, temps, gamma=gamma)
    a8_scores      = {c: alpha * global_scores[c] + (1.0 - alpha) * context_scores[c] for c in CAUSES}
    a8_scores      = normalize_scores(a8_scores)

    # 异常比例 + 因果路径分数（三路融合）
    rul           = float(sample["RUL"])
    anom_combined = score_anomaly_combined(sample, hist_profile, rul=rul)

    final_scores = {
        c: (1.0 - anomaly_weight) * a8_scores[c] + anomaly_weight * anom_combined[c]
        for c in CAUSES
    }
    return normalize_scores(final_scores)


def predict_a8_bagging_mean(
    sample: pd.Series,
    bagging_artifacts: List[Dict[str, object]],
    anomaly_weight: float = 0.15,
) -> Dict[str, float]:
    all_scores = [predict_a8_score(sample, m, anomaly_weight=anomaly_weight) for m in bagging_artifacts]
    merged = {c: float(np.mean([s[c] for s in all_scores])) for c in CAUSES}
    return normalize_scores(merged)


def apply_logit_bias(scores: Dict[str, float], bias: Dict[str, float]) -> Dict[str, float]:
    out = {c: scores[c] * float(np.exp(bias.get(c, 0.0))) for c in CAUSES}
    return normalize_scores(out)


def tune_a8_logit_bias_and_rule_mix(
    val_df: pd.DataFrame,
    bagging_artifacts: List[Dict[str, object]],
    rule_profile: Dict[str, Dict[str, float]],
    graph_profile: Dict[str, Any],
    max_tune_samples: int = MAX_TUNE_SAMPLES,
    anomaly_weight: float = 0.15,
) -> Tuple[Dict[str, float], float]:
    tune_df = val_df
    cause_idx = {c: i for i, c in enumerate(CAUSES)}
    n_val    = len(tune_df)
    ens_mat  = np.zeros((n_val, len(CAUSES)), dtype=float)
    rule_mat = np.zeros((n_val, len(CAUSES)), dtype=float)
    y_true: List[str] = []
    for i, (_, sample) in enumerate(tune_df.iterrows()):
        ens  = predict_a8_bagging_mean(sample, bagging_artifacts, anomaly_weight=anomaly_weight)
        rule = normalize_scores(score_rule_profile(sample, rule_profile, graph_profile))
        for j, c in enumerate(CAUSES):
            ens_mat[i, j]  = ens[c]
            rule_mat[i, j] = rule[c]
        y_true.append(sample["true_cause"])

    def scores_from_bias_rule(b: Dict[str, float], beta: float) -> np.ndarray:
        exp_b = np.array([np.exp(b.get(c, 0.0)) for c in CAUSES], dtype=float)
        adj   = ens_mat * exp_b.reshape(1, -1)
        adj   = adj / (adj.sum(axis=1, keepdims=True) + 1e-15)
        if beta > 1e-9:
            adj = (1.0 - beta) * adj + beta * rule_mat
            adj = adj / (adj.sum(axis=1, keepdims=True) + 1e-15)
        return adj

    def eval_matrix(adj: np.ndarray) -> Tuple[float, float]:
        pred_idx = np.argmax(adj, axis=1)
        pred     = [CAUSES[j] for j in pred_idx]
        hit1 = float(np.mean([pred[i] == y_true[i] for i in range(n_val)]))
        rr = []
        for i in range(n_val):
            rank   = np.argsort(-adj[i])
            true_j = cause_idx[y_true[i]]
            pos    = int(np.where(rank == true_j)[0][0]) + 1
            rr.append(1.0 / pos)
        return round(hit1, 4), round(float(np.mean(rr)), 4)

    best_beta     = 0.0
    best_hit1     = best_mrr = -1.0
    best_bias     = {c: 0.0 for c in CAUSES}
    beta_grid     = [0.0, 0.04, 0.08, 0.12, 0.16, 0.2]
    delta_choices = [-0.35, -0.2, -0.1, 0.1, 0.2, 0.35]

    for beta in beta_grid:
        b = {c: 0.0 for c in CAUSES}
        for _ in range(18):
            improved = False
            for c in CAUSES:
                best_delta = 0.0
                base_h1, base_m = eval_matrix(scores_from_bias_rule(b, beta))
                best_local_h1 = best_local_m = base_h1
                for d in delta_choices:
                    b[c] += d
                    h1, mr = eval_matrix(scores_from_bias_rule(b, beta))
                    b[c] -= d
                    if (h1 > best_local_h1) or (h1 == best_local_h1 and mr > best_local_m):
                        best_local_h1, best_local_m = h1, mr
                        best_delta = d
                if abs(best_delta) > 1e-9:
                    b[c] += best_delta
                    improved = True
            if not improved:
                break
        h1, mr = eval_matrix(scores_from_bias_rule(b, beta))
        if (h1 > best_hit1) or (h1 == best_hit1 and mr > best_mrr):
            best_hit1, best_mrr = h1, mr
            best_beta = beta
            best_bias = b.copy()
    return best_bias, best_beta


def predict_a8_full(
    sample: pd.Series,
    bagging_artifacts: List[Dict[str, object]],
    logit_bias: Dict[str, float],
    rule_mix_beta: float,
    rule_profile: Dict[str, Dict[str, float]],
    graph_profile: Dict[str, Any],
    anomaly_weight: float = 0.15,
) -> Dict[str, float]:
    final_scores = predict_a8_bagging_mean(sample, bagging_artifacts, anomaly_weight=anomaly_weight)
    final_scores = apply_logit_bias(final_scores, logit_bias)
    if rule_mix_beta > 1e-9:
        rule = normalize_scores(score_rule_profile(sample, rule_profile, graph_profile))
        final_scores = {
            c: (1.0 - rule_mix_beta) * final_scores[c] + rule_mix_beta * rule[c] for c in CAUSES
        }
        final_scores = normalize_scores(final_scores)
    return final_scores


# ===================== 简化版（线性融合，向后兼容） =====================

def learn_weights(
    val_df: pd.DataFrame,
    means: Dict[str, np.ndarray],
    stds:  Dict[str, np.ndarray],
    priors: Dict[Tuple[str, str], Dict[str, float]],
    pz_fd: Dict[str, Dict[str, float]],
    py_x_z: Dict[str, Dict[Tuple[str, str], float]],
    graph_profile: Dict[str, Any],
    use_graph_score: bool,
    opt_metric: str,
) -> Dict[str, float]:
    cached_scores: List[Tuple[str, Dict[str, float], Dict[str, float], Dict[str, float], Dict[str, float]]] = []
    for _, row in val_df.iterrows():
        b = normalize_scores(score_baseline(row, means, stds))
        k = normalize_scores(score_kg(row, priors))
        c = normalize_scores(score_causal_do(row, pz_fd, py_x_z))
        g = normalize_scores(score_graph(row, graph_profile))
        cached_scores.append((str(row["true_cause"]), b, k, c, g))

    def search(
        wb_values: np.ndarray,
        wk_values: np.ndarray,
        wc_values: np.ndarray,
        current_best: Dict[str, float],
        best_score: float,
    ) -> Tuple[Dict[str, float], float]:
        best_local = current_best.copy()
        best_local_score = best_score
        for wb in wb_values:
            for wk in wk_values:
                for wc in wc_values:
                    if use_graph_score:
                        wg = 1.0 - wb - wk - wc
                        if wg < -1e-9:
                            continue
                        wg = max(0.0, float(wg))
                    else:
                        wg = 0.0
                        if (wb + wk + wc) < 1.0 - 1e-9 or (wb + wk + wc) > 1.0 + 1e-9:
                            continue
                    rec = []
                    for true_cause, b, k, c, g in cached_scores:
                        s = {x: wb * b[x] + wk * k[x] + wc * c[x] + wg * g[x] for x in CAUSES}
                        s = normalize_scores(s)
                        rec.append({"true": true_cause, "rank": rank_causes(s)})
                    score = objective_score(opt_metric, ranking_metrics(rec))
                    if score > best_local_score:
                        best_local_score = score
                        best_local = {"baseline": float(wb), "kg": float(wk), "causal": float(wc), "graph": float(wg)}
        return best_local, best_local_score

    best = {"baseline": 0.4, "kg": 0.3, "causal": 0.3, "graph": 0.0}
    if use_graph_score:
        coarse = np.round(np.arange(0.0, 1.0001, 0.10), 4)
        best, best_score = search(coarse, coarse, coarse, best, -1.0)
        wb0, wk0, wc0 = best["baseline"], best["kg"], best["causal"]
        fine_wb = np.round(np.arange(max(0.0, wb0 - 0.08), min(1.0, wb0 + 0.08) + 1e-9, 0.02), 4)
        fine_wk = np.round(np.arange(max(0.0, wk0 - 0.08), min(1.0, wk0 + 0.08) + 1e-9, 0.02), 4)
        fine_wc = np.round(np.arange(max(0.0, wc0 - 0.08), min(1.0, wc0 + 0.08) + 1e-9, 0.02), 4)
        best, _ = search(fine_wb, fine_wk, fine_wc, best, best_score)
    else:
        coarse = np.round(np.arange(0.0, 1.0001, 0.05), 4)
        best, best_score = search(coarse, coarse, coarse, best, -1.0)
        wb0, wk0, wc0 = best["baseline"], best["kg"], best["causal"]
        fine_wb = np.round(np.arange(max(0.0, wb0 - 0.1), min(1.0, wb0 + 0.1) + 1e-9, 0.01), 4)
        fine_wk = np.round(np.arange(max(0.0, wk0 - 0.1), min(1.0, wk0 + 0.1) + 1e-9, 0.01), 4)
        fine_wc = np.round(np.arange(max(0.0, wc0 - 0.1), min(1.0, wc0 + 0.1) + 1e-9, 0.01), 4)
        best, _ = search(fine_wb, fine_wk, fine_wc, best, best_score)
    return best


def predict_scores(
    row: pd.Series,
    means: Dict[str, np.ndarray],
    stds:  Dict[str, np.ndarray],
    priors: Dict[Tuple[str, str], Dict[str, float]],
    pz_fd: Dict[str, Dict[str, float]],
    py_x_z: Dict[str, Dict[Tuple[str, str], float]],
    graph_profile: Dict[str, Any],
    use_graph_score: bool,
    weights: Dict[str, float],
    sharpen_gamma: float,
    hist_profile: Optional[Dict[str, Dict[str, float]]] = None,
    anomaly_weight: float = 0.10,
) -> Dict[str, float]:
    b = normalize_scores(score_baseline(row, means, stds))
    k = normalize_scores(score_kg(row, priors))
    c = normalize_scores(score_causal_do(row, pz_fd, py_x_z))
    g = normalize_scores(score_graph(row, graph_profile))
    s = {
        x: weights["baseline"] * b[x] + weights["kg"] * k[x]
        + weights["causal"] * c[x] + (weights.get("graph", 0.0) * g[x] if use_graph_score else 0.0)
        for x in CAUSES
    }
    s = normalize_scores(s)
    if sharpen_gamma > 1.0:
        s = {k_: float(v_**sharpen_gamma) for k_, v_ in s.items()}
        s = normalize_scores(s)
    # 可选：叠加异常比例分数
    if hist_profile and anomaly_weight > 1e-9:
        rul   = float(row["RUL"])
        anom  = score_anomaly_combined(row, hist_profile, rul=rul)
        s = {c_: (1.0 - anomaly_weight) * s[c_] + anomaly_weight * anom[c_] for c_ in CAUSES}
        s = normalize_scores(s)
    return s


# ===================== RUL 评估 =====================

def evaluate_rul_on_official_test(
    test_df: pd.DataFrame,
    means: Dict[str, np.ndarray],
    stds:  Dict[str, np.ndarray],
    priors: Dict[Tuple[str, str], Dict[str, float]],
    pz_fd: Dict[str, Dict[str, float]],
    py_x_z: Dict[str, Dict[Tuple[str, str], float]],
    graph_profile: Dict[str, Any],
    use_graph_score: bool,
    weights: Dict[str, float],
    cause_rul_mean: Dict[str, float],
    sharpen_gamma: float,
    hist_profile: Optional[Dict[str, Dict[str, float]]] = None,
) -> Dict[str, float]:
    last_rows = test_df.sort_values("cycle").groupby(["fd", "unit"], as_index=False).tail(1)
    y_true, y_pred = [], []
    for _, row in last_rows.iterrows():
        sc = predict_scores(row, means, stds, priors, pz_fd, py_x_z, graph_profile,
                            use_graph_score, weights, sharpen_gamma, hist_profile)
        y_pred.append(float(sum(sc[c] * cause_rul_mean[c] for c in CAUSES)))
        y_true.append(float(row["RUL"]))
    yt = np.array(y_true, dtype=float)
    yp = np.array(y_pred, dtype=float)
    return {"MAE": round(float(np.mean(np.abs(yt - yp))), 4),
            "RMSE": round(float(np.sqrt(np.mean((yt - yp)**2))), 4)}


def evaluate_rul_a8_full(
    test_df: pd.DataFrame,
    bagging_artifacts: List[Dict[str, object]],
    logit_bias: Dict[str, float],
    rule_mix_beta: float,
    rule_profile: Dict[str, Dict[str, float]],
    graph_profile: Dict[str, Any],
    cause_rul_mean: Dict[str, float],
    anomaly_weight: float = 0.15,
) -> Dict[str, float]:
    last_rows = test_df.sort_values("cycle").groupby(["fd", "unit"], as_index=False).tail(1)
    y_true, y_pred = [], []
    for _, row in last_rows.iterrows():
        sc = predict_a8_full(row, bagging_artifacts, logit_bias, rule_mix_beta,
                             rule_profile, graph_profile, anomaly_weight=anomaly_weight)
        y_pred.append(float(sum(sc[c] * cause_rul_mean[c] for c in CAUSES)))
        y_true.append(float(row["RUL"]))
    yt = np.array(y_true, dtype=float)
    yp = np.array(y_pred, dtype=float)
    return {"MAE":  round(float(np.mean(np.abs(yt - yp))), 4),
            "RMSE": round(float(np.sqrt(np.mean((yt - yp)**2))), 4)}


# ===================== 实验流程 =====================

def run_experiment_simple(
    fd_list: List[str],
    opt_metric: str,
    sharpen_gamma: float,
    use_graph_score: bool,
    train_part: pd.DataFrame,
    val_part: pd.DataFrame,
    test_df: pd.DataFrame,
) -> Tuple[Dict[str, object], Dict[str, float]]:
    means, stds    = build_baseline_model(train_part)
    priors         = build_kg_priors(train_part)
    pz_fd, py_x_z  = build_causal_tables(train_part)
    graph_profile  = build_graph_profile(train_part)
    hist_profile   = build_histogram_profile(train_part)
    weights        = learn_weights(val_part, means, stds, priors, pz_fd, py_x_z,
                                   graph_profile, use_graph_score, opt_metric)

    rec = []
    for _, row in val_part.iterrows():
        sc = predict_scores(row, means, stds, priors, pz_fd, py_x_z, graph_profile,
                            use_graph_score, weights, sharpen_gamma, hist_profile, anomaly_weight=0.10)
        rec.append({"true": row["true_cause"], "rank": rank_causes(sc)})
    rank_res = ranking_metrics(rec)

    # 故障检测评估
    fd_detect_res = evaluate_fault_detection_metrics(val_part, hist_profile)

    cause_rul_mean = {}
    for c in CAUSES:
        sub = train_part[train_part["true_cause"] == c]
        cause_rul_mean[c] = float(sub["RUL"].mean()) if not sub.empty else float(train_part["RUL"].mean())
    rul_res = evaluate_rul_on_official_test(
        test_df, means, stds, priors, pz_fd, py_x_z, graph_profile,
        use_graph_score, weights, cause_rul_mean, sharpen_gamma, hist_profile
    )

    summary = {
        "Mode": "simple",
        "FD_Sets": ",".join(fd_list),
        "Samples_Train": int(len(train_part)),
        "Samples_Val":   int(len(val_part)),
        "Samples_Test":  int(len(test_df)),
        "Weight_Baseline": round(weights["baseline"], 4),
        "Weight_KG":       round(weights["kg"], 4),
        "Weight_Causal":   round(weights["causal"], 4),
        "Weight_Graph":    round(weights.get("graph", 0.0), 4),
        "Use_Graph_Score": int(use_graph_score),
        "Bagging_Models":  0,
        "A8_RuleMixBeta":  0.0,
        "Avg_LabelConfidence_Train": round(float(train_part["label_confidence"].mean()), 4),
        "Opt_Metric":   opt_metric,
        "Sharpen_Gamma": round(float(sharpen_gamma), 4),
        **rank_res,
        **fd_detect_res,
        **rul_res,
    }
    return summary, cause_rul_mean


def run_experiment_full(
    fd_list: List[str],
    train_part: pd.DataFrame,
    val_part: pd.DataFrame,
    test_df: pd.DataFrame,
    bagging_models: int,
    quick_bagging: bool,
    slow_tune: bool,
    max_tune_samples: int,
    anomaly_weight: float = 0.15,
) -> Tuple[Dict[str, object], Dict[str, float], Dict[str, float], float]:
    base_quick = not slow_tune
    print(f">>> 训练基础 A8 子模型（quick_mode={base_quick}）...", flush=True)
    base_artifact   = train_a8_artifact(train_part, val_part, quick_mode=base_quick, max_tune_samples=max_tune_samples)
    learned_weights = base_artifact["learned_weights"]
    rule_profile    = base_artifact["rule_profile"]
    graph_profile   = base_artifact["graph_profile"]
    hist_profile    = base_artifact["hist_profile"]

    print(f">>> Bagging 训练 {bagging_models} 个子模型（quick_mode={quick_bagging}）...", flush=True)
    bagging_artifacts: List[Dict[str, object]] = []
    rng     = np.random.default_rng(RANDOM_SEED + 999)
    n_train = len(train_part)
    for i in range(bagging_models):
        boot_idx = rng.integers(0, n_train, n_train)
        boot_train = train_part.iloc[boot_idx].reset_index(drop=True)
        bagging_artifacts.append(
            train_a8_artifact(boot_train, val_part, quick_mode=quick_bagging, max_tune_samples=max_tune_samples)
        )
        if (i + 1) % max(1, bagging_models // 5) == 0 or i + 1 == bagging_models:
            print(f"    ... {i + 1}/{bagging_models} 完成", flush=True)

    print(">>> 验证集学习 logit 偏置与规则尾融合...", flush=True)
    a8_logit_bias, a8_rule_mix_beta = tune_a8_logit_bias_and_rule_mix(
        val_part, bagging_artifacts, rule_profile, graph_profile,
        max_tune_samples=max_tune_samples, anomaly_weight=anomaly_weight
    )

    rec = []
    for _, row in val_part.iterrows():
        sc = predict_a8_full(row, bagging_artifacts, a8_logit_bias, a8_rule_mix_beta,
                             rule_profile, graph_profile, anomaly_weight=anomaly_weight)
        rec.append({"true": row["true_cause"], "rank": rank_causes(sc)})
    rank_res = ranking_metrics(rec)

    # 故障检测评估
    fd_detect_res = evaluate_fault_detection_metrics(val_part, hist_profile)

    cause_rul_mean = {}
    for c in CAUSES:
        sub = train_part[train_part["true_cause"] == c]
        cause_rul_mean[c] = float(sub["RUL"].mean()) if not sub.empty else float(train_part["RUL"].mean())
    rul_res = evaluate_rul_a8_full(
        test_df, bagging_artifacts, a8_logit_bias, a8_rule_mix_beta,
        rule_profile, graph_profile, cause_rul_mean, anomaly_weight=anomaly_weight
    )

    # 各 FD 子集独立评估
    fd_breakdown: Dict[str, Dict[str, float]] = {}
    for fd in fd_list:
        sub_val = val_part[val_part["fd"] == fd]
        if sub_val.empty:
            continue
        sub_rec = []
        for _, row in sub_val.iterrows():
            sc = predict_a8_full(row, bagging_artifacts, a8_logit_bias, a8_rule_mix_beta,
                                 rule_profile, graph_profile, anomaly_weight=anomaly_weight)
            sub_rec.append({"true": row["true_cause"], "rank": rank_causes(sc)})
        fd_breakdown[fd] = ranking_metrics(sub_rec)

    summary = {
        "Mode": "full",
        "FD_Sets": ",".join(fd_list),
        "Samples_Train": int(len(train_part)),
        "Samples_Val":   int(len(val_part)),
        "Samples_Test":  int(len(test_df)),
        "Weight_Baseline": round(float(learned_weights["baseline"]), 4),
        "Weight_KG":       round(float(learned_weights["kg"]),       4),
        "Weight_Causal":   round(float(learned_weights["causal"]),   4),
        "Weight_Graph":    0.0,
        "Use_Graph_Score": 0,
        "Bagging_Models":  int(bagging_models),
        "A8_RuleMixBeta":  round(float(a8_rule_mix_beta), 4),
        "A8_Gamma":        round(float(base_artifact["a8_gamma"]),      4),
        "A8_Alpha":        round(float(base_artifact["a8_alpha"]),      4),
        "A8_RuleAlpha":    round(float(base_artifact["a8_rule_alpha"]), 4),
        "Anomaly_Weight":  round(float(anomaly_weight), 4),
        "Avg_LabelConfidence_Train": round(float(train_part["label_confidence"].mean()), 4),
        "Opt_Metric":   "hit1",
        "Sharpen_Gamma": round(float(base_artifact["a8_gamma"]), 4),
        **rank_res,
        **fd_detect_res,
        **rul_res,
    }
    return summary, cause_rul_mean, a8_logit_bias, a8_rule_mix_beta, fd_breakdown


def run_experiment(
    fd_list: List[str],
    train_part: pd.DataFrame,
    val_part: pd.DataFrame,
    test_df: pd.DataFrame,
    out_prefix: str,
    mode: str,
    opt_metric: str,
    sharpen_gamma: float,
    use_graph_score: bool,
    bagging_models: int,
    quick_bagging: bool,
    slow_tune: bool,
    max_tune_samples: int,
    anomaly_weight: float = 0.15,
) -> None:
    print(f"\n[实验范围]")
    print(f"  FD 子集：{fd_list}")
    print(f"  特征数量：{len(FEATURE_COLS)} (传感器: {len(SELECTED_SENSOR_COLS)}, 工况: {len(SETTING_COLS)})")

    a8_logit_bias: Dict[str, float] = {}
    a8_rule_mix_beta = 0.0
    fd_breakdown: Dict[str, Dict[str, float]] = {}

    if mode == "full":
        summary, cause_rul_mean, a8_logit_bias, a8_rule_mix_beta, fd_breakdown = run_experiment_full(
            fd_list, train_part, val_part, test_df,
            bagging_models, quick_bagging, slow_tune, max_tune_samples, anomaly_weight
        )
    else:
        summary, cause_rul_mean = run_experiment_simple(
            fd_list, opt_metric, sharpen_gamma, use_graph_score,
            train_part, val_part, test_df
        )

    summary_df = pd.DataFrame([summary])
    detail_df  = pd.DataFrame([{"Cause": c, "MeanRUL": round(cause_rul_mean[c], 4)} for c in CAUSES])

    out_summary = f"{out_prefix}_summary.csv"
    out_detail  = f"{out_prefix}_cause_rul_profile.csv"
    summary_df.to_csv(out_summary, index=False, encoding="utf-8-sig")
    detail_df.to_csv(out_detail,   index=False, encoding="utf-8-sig")

    print("\n========== CMAPSS A8 实验结果 ==========")
    print(summary_df.to_string(index=False))

    if fd_breakdown:
        print("\n========== FD 子集独立评估 ==========")
        fd_rows = [{"FD": fd, **metrics} for fd, metrics in sorted(fd_breakdown.items())]
        print(pd.DataFrame(fd_rows).to_string(index=False))

    print("\n========== 根因-寿命画像 ==========")
    print(detail_df.to_string(index=False))

    if mode == "full":
        print("\n========== A8 校准参数 ==========")
        print(f"A8 logit_bias: {a8_logit_bias}")
        print(f"A8 rule_mix_beta: {a8_rule_mix_beta:.4f}")
        print(f"Anomaly_Weight: {anomaly_weight:.4f}")

    print(f"\n>>> 已保存: {out_summary}")
    print(f">>> 已保存: {out_detail}")


# ===================== 命令行入口 =====================

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="CMAPSS A8 根因定位实验（检测-定位-解释一体化）")
    parser.add_argument(
        "--fds", type=str, default="FD001,FD002,FD003,FD004",
        help="使用哪些FD子集，逗号分隔，如 FD001,FD003",
    )
    parser.add_argument(
        "--out-prefix", type=str, default="cmapss_a8_experiment", help="输出文件前缀",
    )
    parser.add_argument(
        "--mode", type=str, choices=["full", "simple"], default="full",
        help="full=完整A8(Bagging+log-opinion+logit偏置+异常调整); simple=线性融合",
    )
    parser.add_argument(
        "--bagging-models", type=int, default=A8_BAGGING_MODELS,
        help="完整A8模式下 Bagging 子模型数量",
    )
    parser.add_argument(
        "--quick-bagging", action="store_true",
        help="Bagging 子模型使用 quick_mode（更快，调参网格更粗）",
    )
    parser.add_argument(
        "--slow-tune", action="store_true",
        help="基础 A8 子模型使用完整调参网格（更慢）",
    )
    parser.add_argument(
        "--max-tune-samples", type=int, default=MAX_TUNE_SAMPLES,
        help="调参阶段验证集最大样本数",
    )
    parser.add_argument(
        "--opt-metric", type=str, choices=["hit1", "mrr", "hybrid"], default="hit1",
        help="simple 模式权重学习优化目标",
    )
    parser.add_argument(
        "--sharpen-gamma", type=float, default=1.3,
        help="simple 模式融合概率锐化系数",
    )
    parser.add_argument(
        "--use-graph-score", action="store_true",
        help="simple 模式是否启用图证据分数（四权重融合）",
    )
    parser.add_argument(
        "--anomaly-weight", type=float, default=0.15,
        help="异常比例+因果路径分数在最终融合中的权重（full模式）",
    )
    return parser.parse_args()


if __name__ == "__main__":
    raise SystemExit("本文件不包含数据读取、标签构造和数据集划分。")
