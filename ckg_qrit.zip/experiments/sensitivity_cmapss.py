# -*- coding: utf-8 -*-
"""
CMAPSS A8 敏感性分析（对齐 AI4I 敏感性分析版本）

分析内容：
1. Bagging 子模型数量 n 的影响（n = 3,5,7,10,15,20）
2. 规则尾融合系数 β 的影响（β ∈ [0, 0.25]）
3. 异常比例权重 anomaly_weight 的影响（CMAPSS 特有维度，w ∈ [0, 0.40]）

数据集：CMAPSS FD001（可通过配置扩展到多个子集）
评估指标：Hit@1 / MRR / NDCG@5
"""
from __future__ import annotations

import sys
from pathlib import Path as _SharePath
sys.path.insert(0, str(_SharePath(__file__).resolve().parents[1]))

import logging
import os
import pickle
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from tqdm import tqdm

# ─── 从 CMAPSS 实验模块导入 ─────────────────────────────────────────────────
from ckg_qrit.cmapss_model import (
    A8_BAGGING_MODELS,
    CAUSES,
    MAX_TUNE_SAMPLES,
    RANDOM_SEED,
    apply_logit_bias,
    normalize_scores,
    predict_a8_bagging_mean,
    predict_a8_full,
    rank_causes,
    ranking_metrics,
    score_rule_profile,
    train_a8_artifact,
    tune_a8_logit_bias_and_rule_mix,
)

# ─── 全局常量 ─────────────────────────────────────────────────────────────────
EPS              = 1e-12
SEED_OFFSET_BASE = 999
METRICS          = ["Hit@1", "MRR", "NDCG@5"]
COLOR_MAP        = ["#2F5597", "#7D3C98", "#117A65"]
DEFAULT_BAGGING_LIST     = [3, 5, 7, 10, 15, 20]
DEFAULT_RULE_STEPS       = 21
DEFAULT_RULE_BETA_CAP    = 0.25
DEFAULT_ANOMALY_STEPS    = 17
DEFAULT_ANOMALY_CAP      = 0.40
DEFAULT_FD_LIST          = ["FD001"]
DEFAULT_ANOMALY_WEIGHT   = 0.15
DEFAULT_PLOT_FIGSIZE     = (14.0, 4.2)
DEFAULT_PLOT_DPI         = 300

# ─── 日志配置 ─────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[logging.StreamHandler()],
)
logger = logging.getLogger(__name__)


# ─── 绘图样式 ─────────────────────────────────────────────────────────────────
def set_plot_style() -> None:
    """与消融实验保持一致的绘图样式。"""
    plt.rcParams["font.family"]         = "serif"
    plt.rcParams["font.serif"]          = ["Times New Roman", "DejaVu Serif", "SimSun"]
    plt.rcParams["axes.unicode_minus"]  = False
    plt.rcParams["figure.facecolor"]    = "white"
    plt.rcParams["axes.facecolor"]      = "white"
    plt.rcParams["axes.unicode_minus"]  = False
    plt.rcParams["font.size"]           = 13
    plt.rcParams["axes.labelsize"]      = 15
    plt.rcParams["axes.titlesize"]      = 15
    plt.rcParams["xtick.labelsize"]     = 11
    plt.rcParams["ytick.labelsize"]     = 11
    plt.rcParams["legend.fontsize"]     = 11


# ─── 配置类 ──────────────────────────────────────────────────────────────────
def _parse_env_bool(name: str, default: bool) -> bool:
    val = os.environ.get(name)
    if val is None or not val.strip():
        return default
    return val.strip().lower() in ("1", "true", "yes", "y")


def _parse_env_int(name: str, default: int) -> int:
    val = os.environ.get(name)
    if val is None or not val.strip():
        return default
    try:
        return int(val)
    except ValueError:
        return default


def _parse_env_float(name: str, default: float) -> float:
    val = os.environ.get(name)
    if val is None or not val.strip():
        return default
    try:
        return float(val)
    except ValueError:
        return default


def _parse_int_list(raw: str, default: List[int]) -> List[int]:
    if not raw or not raw.strip():
        return default
    try:
        return sorted(set(int(p.strip()) for p in raw.split(",") if p.strip()))
    except ValueError:
        return default


@dataclass
class CMAPSSSensitivityConfig:
    """CMAPSS 敏感性分析配置类。"""

    fd_list: List[str] = field(default_factory=lambda: list(DEFAULT_FD_LIST))

    # Bagging 敏感性
    skip_bagging: bool     = field(default_factory=lambda: _parse_env_bool("SENS_SKIP_BAGGING", False))
    bagging_list: List[int] = field(
        default_factory=lambda: _parse_int_list(
            os.environ.get("SENS_BAGGING", ""), DEFAULT_BAGGING_LIST
        )
    )

    # 规则 β 敏感性
    skip_rule_beta: bool = field(default_factory=lambda: _parse_env_bool("SENS_SKIP_RULE_BETA", False))
    rule_steps: int      = field(default_factory=lambda: _parse_env_int("SENS_RULE_STEPS", DEFAULT_RULE_STEPS))
    beta_cap: float      = field(default_factory=lambda: _parse_env_float("SENS_RULE_BETA_CAP", DEFAULT_RULE_BETA_CAP))

    # 异常权重敏感性（CMAPSS 特有）
    skip_anomaly_weight: bool = field(default_factory=lambda: _parse_env_bool("SENS_SKIP_ANOMALY", False))
    anomaly_steps: int        = field(default_factory=lambda: _parse_env_int("SENS_ANOMALY_STEPS", DEFAULT_ANOMALY_STEPS))
    anomaly_cap: float        = field(default_factory=lambda: _parse_env_float("SENS_ANOMALY_CAP", DEFAULT_ANOMALY_CAP))

    # 通用
    quick_mode: bool   = field(default_factory=lambda: _parse_env_bool("SENS_QUICK", True))
    seed_offset: int   = field(default_factory=lambda: _parse_env_int("SENS_SEED_OFFSET", 0))
    anomaly_weight_ref: float = field(
        default_factory=lambda: _parse_env_float("SENS_ANOMALY_WEIGHT_REF", DEFAULT_ANOMALY_WEIGHT)
    )
    max_tune_samples: int = field(
        default_factory=lambda: _parse_env_int("SENS_MAX_TUNE_SAMPLES", MAX_TUNE_SAMPLES)
    )
    plot_figsize: Tuple[float, float] = DEFAULT_PLOT_FIGSIZE
    plot_dpi: int = DEFAULT_PLOT_DPI
    val_ratio: float  = 0.15
    test_ratio: float = 0.15

    def validate(self) -> None:
        if self.skip_bagging and self.skip_rule_beta and self.skip_anomaly_weight:
            raise ValueError("三类敏感性分析不能同时跳过")
        if not self.bagging_list and not self.skip_bagging:
            raise ValueError("bagging_list 不能为空（当 skip_bagging=False 时）")
        if self.rule_steps < 3:
            raise ValueError(f"rule_steps 必须 ≥ 3，当前值：{self.rule_steps}")
        if self.beta_cap < 0:
            raise ValueError(f"beta_cap 不能为负，当前值：{self.beta_cap}")
        if self.anomaly_cap < 0 or self.anomaly_cap > 1:
            raise ValueError(f"anomaly_cap 超出 [0,1] 范围，当前值：{self.anomaly_cap}")
        if not self.fd_list:
            raise ValueError("fd_list 不能为空")


# ─── 核心评估函数 ─────────────────────────────────────────────────────────────

def eval_a8_on_test(
    test_df: pd.DataFrame,
    bagging_artifacts: List[Dict[str, Any]],
    rule_profile: Dict[str, Any],
    graph_profile: Dict[str, Any],
    logit_bias: Dict[str, float],
    rule_mix_beta: float,
    anomaly_weight: float = DEFAULT_ANOMALY_WEIGHT,
) -> Dict[str, float]:
    """
    在测试集上完整评估 A8 模型（predict_a8_full 路径）。

    Parameters
    ----------
    test_df          : 测试样本 DataFrame（含 true_cause 列）
    bagging_artifacts: Bagging 子模型列表
    rule_profile     : 机理规则画像（来自第一个子模型）
    graph_profile    : 图证据画像（来自第一个子模型）
    logit_bias       : 每类 logit 偏置
    rule_mix_beta    : 规则尾融合系数
    anomaly_weight   : 异常比例权重

    Returns
    -------
    Dict[str, float]: Hit@1 / MRR / NDCG@5
    """
    if test_df.empty:
        raise ValueError("测试集不能为空")
    if not bagging_artifacts:
        raise ValueError("Bagging 模型列表不能为空")

    records = []
    for _, sample in test_df.iterrows():
        final_scores = predict_a8_full(
            sample,
            bagging_artifacts,
            logit_bias,
            rule_mix_beta,
            rule_profile,
            graph_profile,
            anomaly_weight=anomaly_weight,
        )
        records.append({"true": sample["true_cause"], "rank": rank_causes(final_scores)})

    metrics = ranking_metrics(records)
    # 只保留三个核心指标
    return {m: metrics[m] for m in METRICS if m in metrics}


# ─── Bagging 子模型训练 ───────────────────────────────────────────────────────

def train_bagging_artifacts(
    train_df: pd.DataFrame,
    val_df: pd.DataFrame,
    n_models: int,
    quick_mode: bool,
    seed_offset: int,
    max_tune_samples: int = MAX_TUNE_SAMPLES,
) -> Tuple[List[Dict[str, Any]], Dict[str, Any], Dict[str, Any]]:
    """
    依次训练 n_models 个 Bootstrap 子模型。

    Returns
    -------
    (artifacts, rule_profile, graph_profile)
    rule_profile / graph_profile 取自第一个子模型，在评估阶段复用。
    """
    if n_models < 1:
        raise ValueError(f"子模型数量不能小于 1（当前值：{n_models}）")

    base_seed = RANDOM_SEED + SEED_OFFSET_BASE + int(seed_offset)
    rng       = np.random.default_rng(base_seed)
    n_train   = len(train_df)

    artifacts: List[Optional[Dict[str, Any]]] = []
    rule_profile_ref: Optional[Dict[str, Any]]  = None
    graph_profile_ref: Optional[Dict[str, Any]] = None

    for i in tqdm(range(n_models), desc=f"训练 Bagging 子模型（共 {n_models} 个）"):
        seed = int(rng.integers(0, 1_000_000))
        boot_rng = np.random.default_rng(seed)
        boot_idx   = boot_rng.integers(0, n_train, n_train)
        boot_train = train_df.iloc[boot_idx].reset_index(drop=True)
        try:
            art = train_a8_artifact(
                boot_train, val_df,
                quick_mode=quick_mode,
                max_tune_samples=max_tune_samples,
            )
            if rule_profile_ref is None:
                rule_profile_ref  = art["rule_profile"]
                graph_profile_ref = art["graph_profile"]
            artifacts.append(art)
        except Exception as exc:
            logger.error(f"子模型 {i} 训练失败：{exc}", exc_info=True)

    assert rule_profile_ref is not None and graph_profile_ref is not None, \
        "至少需要一个成功训练的子模型来获取 rule_profile / graph_profile"

    return [a for a in artifacts if a is not None], rule_profile_ref, graph_profile_ref


# ─── 三类敏感性分析 ───────────────────────────────────────────────────────────

def run_sensitivity_bagging(
    train_df: pd.DataFrame,
    val_df: pd.DataFrame,
    test_df: pd.DataFrame,
    config: CMAPSSSensitivityConfig,
) -> pd.DataFrame:
    """Bagging 规模敏感性分析：前缀复用最大规模已训练子模型。"""
    bagging_scan = sorted(set(int(n) for n in config.bagging_list if int(n) > 0))
    if not bagging_scan:
        return pd.DataFrame()

    max_n = max(bagging_scan)
    logger.info(f"[Bagging] 先训练最大规模 n={max_n}，再逐步截取前缀子集")
    all_arts, rule_profile, graph_profile = train_bagging_artifacts(
        train_df, val_df, max_n,
        config.quick_mode, config.seed_offset, config.max_tune_samples,
    )

    rows = []
    for n in tqdm(bagging_scan, desc="Bagging 规模扫描"):
        try:
            arts = all_arts[:n]
            logit_bias, rule_mix_beta = tune_a8_logit_bias_and_rule_mix(
                val_df, arts, rule_profile, graph_profile,
                max_tune_samples=config.max_tune_samples,
                anomaly_weight=config.anomaly_weight_ref,
            )
            metrics = eval_a8_on_test(
                test_df, arts, rule_profile, graph_profile,
                logit_bias, rule_mix_beta, config.anomaly_weight_ref,
            )
            rows.append({"n_bagging": n, "rule_mix_tuned": round(rule_mix_beta, 4), **metrics})
        except Exception as exc:
            logger.error(f"Bagging n={n} 评估失败：{exc}", exc_info=True)

    return pd.DataFrame(rows)


def run_sensitivity_rule_beta(
    train_df: pd.DataFrame,
    val_df: pd.DataFrame,
    test_df: pd.DataFrame,
    config: CMAPSSSensitivityConfig,
) -> pd.DataFrame:
    """规则尾融合系数 β 敏感性分析：固定 Bagging+logit，扫描 β ∈ [0, beta_cap]。"""
    logger.info(f"[Rule-β] 训练参考 Bagging 模型（n={A8_BAGGING_MODELS}）")
    arts, rule_profile, graph_profile = train_bagging_artifacts(
        train_df, val_df, A8_BAGGING_MODELS,
        config.quick_mode, config.seed_offset + 7, config.max_tune_samples,
    )
    logit_bias, _ = tune_a8_logit_bias_and_rule_mix(
        val_df, arts, rule_profile, graph_profile,
        max_tune_samples=config.max_tune_samples,
        anomaly_weight=config.anomaly_weight_ref,
    )

    beta_grid = np.linspace(0.0, config.beta_cap, config.rule_steps)
    rows = []
    for beta in tqdm(beta_grid, desc="规则 β 扫描"):
        try:
            metrics = eval_a8_on_test(
                test_df, arts, rule_profile, graph_profile,
                logit_bias, float(beta), config.anomaly_weight_ref,
            )
            rows.append({"rule_beta": float(beta), **metrics})
        except Exception as exc:
            logger.error(f"β={beta:.4f} 评估失败：{exc}", exc_info=True)

    return pd.DataFrame(rows)


def run_sensitivity_anomaly_weight(
    train_df: pd.DataFrame,
    val_df: pd.DataFrame,
    test_df: pd.DataFrame,
    config: CMAPSSSensitivityConfig,
) -> pd.DataFrame:
    """
    异常比例权重 anomaly_weight 敏感性分析（CMAPSS 特有）。

    固定 Bagging 规模 + logit_bias，扫描 anomaly_weight ∈ [0, anomaly_cap]。
    anomaly_weight=0 等价于纯 A8 模型分数，无异常比例/因果路径调整。
    """
    logger.info(f"[Anomaly-w] 训练参考 Bagging 模型（n={A8_BAGGING_MODELS}）")
    arts, rule_profile, graph_profile = train_bagging_artifacts(
        train_df, val_df, A8_BAGGING_MODELS,
        config.quick_mode, config.seed_offset + 13, config.max_tune_samples,
    )
    logit_bias, rule_mix_beta = tune_a8_logit_bias_and_rule_mix(
        val_df, arts, rule_profile, graph_profile,
        max_tune_samples=config.max_tune_samples,
        anomaly_weight=config.anomaly_weight_ref,
    )

    anomaly_grid = np.linspace(0.0, config.anomaly_cap, config.anomaly_steps)
    rows = []
    for aw in tqdm(anomaly_grid, desc="异常权重扫描"):
        try:
            metrics = eval_a8_on_test(
                test_df, arts, rule_profile, graph_profile,
                logit_bias, rule_mix_beta, float(aw),
            )
            rows.append({"anomaly_weight": float(aw), **metrics})
        except Exception as exc:
            logger.error(f"anomaly_weight={aw:.4f} 评估失败：{exc}", exc_info=True)

    return pd.DataFrame(rows)


# ─── 可视化 ───────────────────────────────────────────────────────────────────

def _plot_one_sensitivity(
    ax: plt.Axes,
    x_vals: np.ndarray,
    y_vals: np.ndarray,
    xlabel: str,
    ylabel: str,
    title: str,
    color: str,
    marker: str = "o",
    x_ticks: Optional[np.ndarray] = None,
) -> None:
    ax.plot(x_vals, y_vals, marker=marker, linewidth=2.0, markersize=6,
            color=color, label=ylabel)
    ax.set_xlabel(xlabel, fontsize=13, fontweight="bold")
    ax.set_ylabel(ylabel, fontsize=13, fontweight="bold")
    ax.set_title(title, fontsize=14, fontweight="bold")
    ax.grid(True, linestyle="--", alpha=0.35)
    ax.legend(loc="best", fontsize=10)
    if x_ticks is not None:
        ax.set_xticks(x_ticks)
    # Y 轴范围：以数据为中心，留出 5% 上下边距
    if len(y_vals) > 0:
        ymin, ymax = y_vals.min(), y_vals.max()
        pad = max((ymax - ymin) * 0.12, 0.01)
        ax.set_ylim(max(0.0, ymin - pad), min(1.0, ymax + pad))


def plot_sensitivity_curves(
    df_bag: pd.DataFrame,
    df_beta: pd.DataFrame,
    df_anomaly: pd.DataFrame,
    out_prefix: str,
    config: CMAPSSSensitivityConfig,
) -> None:
    """
    绘制三类敏感性曲线，每类一张图（3 子图，各指标一列）。
    - 图1：Hit@1 / MRR / NDCG@5 vs Bagging 子模型数
    - 图2：Hit@1 / MRR / NDCG@5 vs 规则尾融合系数 β
    - 图3：Hit@1 / MRR / NDCG@5 vs 异常比例权重（CMAPSS 特有）
    """
    set_plot_style()

    # ── 图1：Bagging 敏感性 ──────────────────────────────────────────────────
    fig1, axes1 = plt.subplots(1, 3, figsize=config.plot_figsize)
    for i, metric in enumerate(METRICS):
        if not df_bag.empty:
            _plot_one_sensitivity(
                axes1[i],
                df_bag["n_bagging"].values.astype(float),
                df_bag[metric].values.astype(float),
                xlabel="Bagging 子模型数 n",
                ylabel=metric,
                title=f"A8 (CMAPSS)：{metric} vs n",
                color=COLOR_MAP[i],
                marker="o",
                x_ticks=df_bag["n_bagging"].values,
            )
        else:
            axes1[i].set_title(f"(无数据) {metric} vs Bagging n")

    fig1.suptitle(
        f"CMAPSS A8 敏感性分析（1/3）：Bagging 规模 | FD：{','.join(config.fd_list)}",
        fontsize=13, fontweight="bold", y=1.02,
    )
    fig1.tight_layout()
    p1 = f"{out_prefix}_bagging.png"
    fig1.savefig(p1, dpi=config.plot_dpi, bbox_inches="tight")
    plt.close(fig1)
    logger.info(f"Bagging 敏感性曲线已保存：{p1}")

    # ── 图2：规则 β 敏感性 ──────────────────────────────────────────────────
    fig2, axes2 = plt.subplots(1, 3, figsize=config.plot_figsize)
    for i, metric in enumerate(METRICS):
        if not df_beta.empty:
            _plot_one_sensitivity(
                axes2[i],
                df_beta["rule_beta"].values.astype(float),
                df_beta[metric].values.astype(float),
                xlabel=r"规则融合系数 $\beta$",
                ylabel=metric,
                title=f"A8 (CMAPSS)：{metric} vs β",
                color=COLOR_MAP[i],
                marker="s",
            )
        else:
            axes2[i].set_title(f"(无数据) {metric} vs β")

    fig2.suptitle(
        f"CMAPSS A8 敏感性分析（2/3）：规则尾融合系数 β | FD：{','.join(config.fd_list)}",
        fontsize=13, fontweight="bold", y=1.02,
    )
    fig2.tight_layout()
    p2 = f"{out_prefix}_rule_beta.png"
    fig2.savefig(p2, dpi=config.plot_dpi, bbox_inches="tight")
    plt.close(fig2)
    logger.info(f"规则 β 敏感性曲线已保存：{p2}")

    # ── 图3：anomaly_weight 敏感性（CMAPSS 特有）──────────────────────────
    fig3, axes3 = plt.subplots(1, 3, figsize=config.plot_figsize)
    for i, metric in enumerate(METRICS):
        if not df_anomaly.empty:
            _plot_one_sensitivity(
                axes3[i],
                df_anomaly["anomaly_weight"].values.astype(float),
                df_anomaly[metric].values.astype(float),
                xlabel="异常比例权重 w",
                ylabel=metric,
                title=f"A8 (CMAPSS)：{metric} vs w",
                color=COLOR_MAP[i],
                marker="^",
            )
        else:
            axes3[i].set_title(f"(无数据) {metric} vs anomaly_weight")

    fig3.suptitle(
        f"CMAPSS A8 敏感性分析（3/3）：异常比例权重 | FD：{','.join(config.fd_list)}",
        fontsize=13, fontweight="bold", y=1.02,
    )
    fig3.tight_layout()
    p3 = f"{out_prefix}_anomaly_weight.png"
    fig3.savefig(p3, dpi=config.plot_dpi, bbox_inches="tight")
    plt.close(fig3)
    logger.info(f"异常权重敏感性曲线已保存：{p3}")


# ─── 结果保存 ─────────────────────────────────────────────────────────────────

def save_results(
    df_bag: pd.DataFrame,
    df_beta: pd.DataFrame,
    df_anomaly: pd.DataFrame,
    config: CMAPSSSensitivityConfig,
    out_prefix: str = "sensitivity_a8_cmapss",
) -> None:
    """保存三类敏感性分析结果（CSV + Pickle）。"""
    for df, suffix, label in [
        (df_bag,     "_bagging.csv",       "Bagging"),
        (df_beta,    "_rule_beta.csv",     "规则β"),
        (df_anomaly, "_anomaly_weight.csv","异常权重"),
    ]:
        if not df.empty:
            path = f"{out_prefix}{suffix}"
            df.to_csv(path, index=False, encoding="utf-8-sig")
            logger.info(f"{label} 结果已保存：{path}")

    pkl_path = f"{out_prefix}_all_results.pkl"
    with open(pkl_path, "wb") as f:
        pickle.dump({"config": config,
                     "bagging_results": df_bag,
                     "beta_results": df_beta,
                     "anomaly_results": df_anomaly}, f)
    logger.info(f"全部结果已保存（Pickle）：{pkl_path}")


# ─── 打印工具 ─────────────────────────────────────────────────────────────────

def _print_section(title: str, df: pd.DataFrame, x_col: str) -> None:
    sep = "=" * 70
    logger.info(f"\n{sep}")
    logger.info(f"  {title}")
    logger.info(sep)
    if df.empty:
        logger.info("  （无数据）")
    else:
        step = max(1, len(df) // 8)
        logger.info(df.iloc[::step].to_string(index=False))
        if len(df) % step != 0:
            logger.info(df.tail(1).to_string(index=False))
    logger.info(sep)


# ─── 主函数 ───────────────────────────────────────────────────────────────────

def main(
    train_df: pd.DataFrame,
    val_df: pd.DataFrame,
    test_df: pd.DataFrame,
    config: Optional[CMAPSSSensitivityConfig] = None,
) -> None:
    try:
        # 1. 加载配置并校验
        config = config or CMAPSSSensitivityConfig()
        config.validate()
        logger.info(f"配置加载完成：{config}")
        logger.info(
            f"使用已准备样本：训练集 {len(train_df)} | 验证集 {len(val_df)} | 测试集 {len(test_df)}"
        )

        # 3. Bagging 规模敏感性分析
        df_bag = pd.DataFrame()
        if not config.skip_bagging:
            logger.info(">>> 开始 Bagging 规模敏感性分析...")
            df_bag = run_sensitivity_bagging(train_df, val_df, test_df, config)
        else:
            logger.info("跳过 Bagging 规模敏感性分析（skip_bagging=True）")

        # 4. 规则 β 敏感性分析
        df_beta = pd.DataFrame()
        if not config.skip_rule_beta:
            logger.info(">>> 开始规则 β 敏感性分析...")
            df_beta = run_sensitivity_rule_beta(train_df, val_df, test_df, config)
        else:
            logger.info("跳过规则 β 敏感性分析（skip_rule_beta=True）")

        # 5. anomaly_weight 敏感性分析
        df_anomaly = pd.DataFrame()
        if not config.skip_anomaly_weight:
            logger.info(">>> 开始异常比例权重敏感性分析...")
            df_anomaly = run_sensitivity_anomaly_weight(train_df, val_df, test_df, config)
        else:
            logger.info("跳过异常比例权重敏感性分析（skip_anomaly_weight=True）")

        # 6. 结果打印
        _print_section("Bagging 规模敏感性分析结果（测试集）",   df_bag,     "n_bagging")
        _print_section("规则 β 敏感性分析结果（测试集，节选）", df_beta,    "rule_beta")
        _print_section("异常权重敏感性分析结果（测试集，节选）", df_anomaly, "anomaly_weight")

        # 7. 结果保存
        out_prefix = f"sensitivity_a8_cmapss_{'_'.join(config.fd_list)}"
        save_results(df_bag, df_beta, df_anomaly, config, out_prefix)

        # 8. 绘图
        if any(not d.empty for d in [df_bag, df_beta, df_anomaly]):
            logger.info(">>> 绘制敏感性曲线...")
            plot_sensitivity_curves(df_bag, df_beta, df_anomaly, out_prefix, config)
        else:
            logger.warning("跳过绘图：全部结果为空")

        logger.info(">>> CMAPSS 敏感性分析完成！")

    except Exception as exc:
        logger.error(f"分析过程出错：{exc}", exc_info=True)
        raise SystemExit(1)


if __name__ == "__main__":
    raise SystemExit("敏感性分析不包含数据读取与划分。")
