# -*- coding: utf-8 -*-
"""
CMAPSS 根因定位：对比实验脚本（与 A8 对照）

本脚本依赖 cmapss实验最终版.py 提供核心 A8 算法实现。

对比方法（与 AI4I 版编号对齐）：
- ① Apriori 风格关联规则（传感器阈值→根因共现）
- ③ 知识图谱路径先验（纯 KG 上下文先验，无因果/熵权）
- ④ Noisy-OR 式简单概率叠加（朴素独立证据叠加）
- ⑤ FP-Growth 风格频繁模式（多传感器联合规则）
- ⑦ 贝叶斯网络（GaussianNB / 分箱 + MultinomialNB）
- ⑧ FTA 故障树规则（AND/OR 门 + 机理诊断）
- ⑨ 本文方法 A8（完整 CMAPSS 版，来自 cmapss实验最终版）

评估指标：Hit@1、MRR、NDCG@5（越大越好）。
数据划分：按 (fd, unit) 分组切分（防止同一机组时序数据泄漏）。

根因类别（弱监督标签）：
  HPC_Early  / HPC_Late  / Fan_Early / Fan_Late / Mixed_Stress

CLI 参数（与 cmapss实验最终版.py 对齐）：
  --fds FD001,FD002,FD003,FD004  — 使用哪些 FD 子集（默认全部）。
  --bagging-models N             — Bagging 子模型数，默认 A8_BAGGING_MODELS=10。
  --quick-bagging                — Bagging 子模型使用粗粒度调参（加速；默认不开启）。
  --slow-tune                    — 基础子模型用完整调参网格（极慢，同 cmapss实验最终版 --slow-tune）。

环境变量（可选覆盖）：
  COMPARE_SKIP_A8=1        — 跳过 A8，仅输出六种基线（最快）。
  COMPARE_A8_MODE=fixed    — 改用写死指标（默认 run，即实时训练）。
  COMPARE_A8_FIXED=h,m,n   — fixed 模式 A8 指标，默认 0.9927,0.9964,0.9973。
  COMPARE_BAGGING=n        — run 模式 Bagging 子模型数（覆盖 --bagging-models）。
  COMPARE_A8_SLOW=1        — run 模式：基础子模型用完整调参（同 --slow-tune）。
  COMPARE_ML_BASELINE=full — ⑦ 使用 GaussianNB（默认为分箱+MultinomialNB）。
  COMPARE_GNB_VAR_SMOOTHING=x — GaussianNB 方差平滑（须披露非默认值）。
"""
from __future__ import annotations

import sys
from pathlib import Path as _SharePath
sys.path.insert(0, str(_SharePath(__file__).resolve().parents[1]))

import os
from typing import Any, Dict, List, Tuple

import numpy as np
import pandas as pd
from sklearn.naive_bayes import GaussianNB, MultinomialNB
from sklearn.preprocessing import KBinsDiscretizer, LabelEncoder

from ckg_qrit.cmapss_model import (
    A8_BAGGING_MODELS,
    CAUSES,
    FEATURE_COLS,
    MAX_TUNE_SAMPLES,
    RANDOM_SEED,
    apply_logit_bias,
    build_graph_profile,
    build_kg_priors,
    build_rule_profile,
    build_val_score_cache,
    normalize_scores,
    predict_a8_bagging_mean,
    predict_a8_full,
    rank_causes,
    ranking_metrics,
    score_kg,
    score_rule_profile,
    train_a8_artifact,
    tune_a8_logit_bias_and_rule_mix,
)


# ---------------------------------------------------------------------------
# 基线评分函数（适配 CMAPSS 传感器语义）
# ---------------------------------------------------------------------------

def score_apriori(
    sample: pd.Series,
    temp_median: float,
    flow_median: float,
) -> Dict[str, float]:
    """
    ① Apriori 风格关联规则：传感器中位数阈值→根因软分数。
    规则仅用统计共现，无因果干预或学习权重。
    使用中位数（q50）而非 q60，确保与标签构造逻辑（q60）存在信息隔离。
    """
    scores = {c: 0.2 for c in CAUSES}
    temp_ind = float(sample["s2"] + sample["s3"] + sample["s4"])
    flow_ind = float(sample["s11"] + sample["s12"] + sample["s15"])
    rul = float(sample["RUL"])
    late = rul <= 40.0
    fd = str(sample["fd"])

    if temp_ind >= temp_median:
        scores["Fan_Late" if late else "Fan_Early"] = 0.75
    if flow_ind >= flow_median:
        scores["HPC_Late" if late else "HPC_Early"] = 0.75
    if fd in ("FD001", "FD002"):
        scores["Fan_Early"] = 0.10
        scores["Fan_Late"] = 0.10
        scores["Mixed_Stress"] = 0.10
    if temp_ind >= temp_median and flow_ind >= flow_median:
        scores["Mixed_Stress"] = 0.65
    return scores


def score_kg_path(
    sample: pd.Series,
    kg_priors: Dict[Tuple[str, str], Dict[str, float]],
) -> Dict[str, float]:
    """
    ③ 纯 (fd, load_state) 上下文 KG 先验，无因果干预、无熵权。
    """
    return score_kg(sample, kg_priors)


def score_noisy_or(
    sample: pd.Series,
    temp_mean: float,
    temp_std: float,
    flow_mean: float,
    flow_std: float,
) -> Dict[str, float]:
    """
    ④ Noisy-OR 式叠加：各传感器证据独立、软性叠加，无知识先验、无因果干预。

    关键设计原则：
    - 使用 z-score（均值/标准差）而非 q60 归一化，确保不复用标签构造所用的最优决策边界
    - 不携带 FD 特定约束（域无关假设），体现"通用型" Noisy-OR 的朴素独立性
    - RUL 判断使用连续 sigmoid（late/early 不确定性建模）
    """
    temp_ind = float(sample["s2"] + sample["s3"] + sample["s4"])
    flow_ind = float(sample["s11"] + sample["s12"] + sample["s15"])
    rul = float(sample["RUL"])

    # z-score sigmoid，中心为均值（非 q60），不知道最优决策边界
    t_score = float(1.0 / (1.0 + np.exp(-((temp_ind - temp_mean) / (temp_std * 1.5 + 1e-6)))))
    f_score = float(1.0 / (1.0 + np.exp(-((flow_ind - flow_mean) / (flow_std * 1.5 + 1e-6)))))
    # RUL 连续 sigmoid（不确定边界 ±20 cycles）
    late = float(1.0 / (1.0 + np.exp(-(40.0 - rul) / 20.0)))
    early = 1.0 - late

    # 无 FD 约束：纯传感器证据叠加（域无关）
    scores = {
        "HPC_Early": max(1e-6, f_score * early),
        "HPC_Late": max(1e-6, f_score * late),
        "Fan_Early": max(1e-6, t_score * early),
        "Fan_Late": max(1e-6, t_score * late),
        "Mixed_Stress": max(1e-6, t_score * f_score * 0.5),
    }
    return scores


def score_fp_growth(
    sample: pd.Series,
    temp_median: float,
    flow_median: float,
    temp_q75: float,
    flow_q75: float,
) -> Dict[str, float]:
    """
    ⑤ FP-Growth 风格强关联：多传感器联合阈值规则（高频项集→推断），
    无因果干预、无 KG 先验、无权重学习。
    使用 q50（普通异常）+ q75（高度异常）双阈值区分频繁/强关联项集，
    避免直接复用标签构造所用的 q60 最优决策边界。
    """
    scores = {c: 0.2 for c in CAUSES}
    temp_ind = float(sample["s2"] + sample["s3"] + sample["s4"])
    flow_ind = float(sample["s11"] + sample["s12"] + sample["s15"])
    rul = float(sample["RUL"])
    late = rul <= 40.0
    load = str(sample["load_state"])
    fd = str(sample["fd"])

    mod_temp = temp_ind >= temp_median
    hi_temp = temp_ind >= temp_q75
    mod_flow = flow_ind >= flow_median
    hi_flow = flow_ind >= flow_q75

    # 强关联：高流量异常 → HPC（仅流量不伴随高温）
    if mod_flow and not mod_temp:
        scores["HPC_Late" if late else "HPC_Early"] = 0.80
    # 高流量异常（强）
    if hi_flow:
        scores["HPC_Late" if late else "HPC_Early"] = 0.85
    # 强关联：温度高 → Fan（非 FD001/002）
    if mod_temp and not mod_flow and fd not in ("FD001", "FD002"):
        scores["Fan_Late" if late else "Fan_Early"] = 0.80
    if hi_temp and fd not in ("FD001", "FD002"):
        scores["Fan_Late" if late else "Fan_Early"] = 0.85
    # 联合高异常 + 高负荷 → Mixed（仅 FD003/004）
    if hi_temp and hi_flow and load == "high" and fd not in ("FD001", "FD002"):
        scores["Mixed_Stress"] = 0.86
    if fd in ("FD001", "FD002"):
        scores["Fan_Early"] = 0.10
        scores["Fan_Late"] = 0.10
        scores["Mixed_Stress"] = 0.10
    return scores


def train_bn(
    train_df: pd.DataFrame,
    constrained: bool = False,
) -> Tuple[Any, LabelEncoder, Any]:
    """
    ⑦ 高斯朴素贝叶斯（full）或分箱+多项式 NB（constrained）。
    返回 (model, le, discretizer_or_None)。
    """
    le = LabelEncoder()
    X = train_df[FEATURE_COLS].values.astype(float)
    y = le.fit_transform(train_df["true_cause"])
    if not constrained:
        model = GaussianNB(var_smoothing=_gnb_var_smoothing())
        model.fit(X, y)
        return model, le, None
    disc = KBinsDiscretizer(
        n_bins=4,
        encode="ordinal",
        strategy="quantile",
        subsample=min(20000, len(train_df)),
    )
    Xb = np.clip(disc.fit_transform(X), 0, 1e9).astype(np.int64)
    model = MultinomialNB(alpha=4.0)
    model.fit(Xb, y)
    return model, le, disc


def score_bn(
    sample: pd.Series,
    model: Any,
    le: LabelEncoder,
    discretizer: Any,
) -> Dict[str, float]:
    x = sample[FEATURE_COLS].values.astype(float).reshape(1, -1)
    if discretizer is not None:
        x = np.clip(discretizer.transform(x), 0, 1e9).astype(np.int64)
    prob = model.predict_proba(x)[0]
    classes = model.classes_
    out = {c: 1e-9 for c in CAUSES}
    for i, cid in enumerate(classes):
        try:
            cause = le.inverse_transform([int(np.asarray(cid).item())])[0]
        except (TypeError, ValueError):
            cause = str(cid)
        if cause in out:
            out[cause] = float(prob[i])
    return out


def score_fta(
    sample: pd.Series,
    temp_mean: float,
    temp_std: float,
    flow_mean: float,
    flow_std: float,
) -> Dict[str, float]:
    """
    ⑧ FTA 故障树：AND/OR 逻辑门 + 工程域规则（无数据学习）。

    关键设计原则：
    - 门阈值来自训练集均值 + 工程偏置（mean + 0.4*std），代表"专家判定超出平均水平"
    - 不使用 q60（标签构造所用最优分位数），避免循环评估
    - 保留 FD 约束（FTA 是域专家方法，知道 FD001/002 仅 HPC 退化）
    - RUL 使用较窄 sigmoid（±10 cycles 不确定性），专家对退化阶段判断偏确定

    顶事件通过 AND/OR 门激活：
    - HPC: 流量偏高 OR 门
    - Fan: 温度偏高 OR 门（仅 FD003/004）
    - Mixed: 温度 AND 流量均超高 AND 门
    """
    scores = {c: 0.15 for c in CAUSES}
    temp_ind = float(sample["s2"] + sample["s3"] + sample["s4"])
    flow_ind = float(sample["s11"] + sample["s12"] + sample["s15"])
    rul = float(sample["RUL"])
    load = str(sample["load_state"])
    fd = str(sample["fd"])

    # 工程阈值：均值 + 0.4σ（专家判定"高于平均退化水平"）
    temp_thr = temp_mean + 0.4 * temp_std
    flow_thr = flow_mean + 0.4 * flow_std
    temp_hi_thr = temp_mean + 1.2 * temp_std
    flow_hi_thr = flow_mean + 1.2 * flow_std

    # 中间事件 sigmoid 门（以工程阈值为中心，±0.5σ 宽度）
    hpc_gate = float(1.0 / (1.0 + np.exp(-(flow_ind - flow_thr) / (flow_std * 0.5 + 1e-6))))
    fan_gate = float(1.0 / (1.0 + np.exp(-(temp_ind - temp_thr) / (temp_std * 0.5 + 1e-6))))
    # 专家对退化阶段判断较确定（窄 sigmoid，RUL 不确定带 ±10 cycles）
    late_gate = float(1.0 / (1.0 + np.exp(-(40.0 - rul) / 10.0)))
    early_gate = 1.0 - late_gate
    load_gate = 0.80 if load == "high" else 0.30

    scores["HPC_Early"] = max(0.15, hpc_gate * early_gate)
    scores["HPC_Late"] = max(0.15, hpc_gate * late_gate)

    fan_mul = 0.12 if fd in ("FD001", "FD002") else 1.0
    scores["Fan_Early"] = max(0.10, fan_gate * early_gate * fan_mul)
    scores["Fan_Late"] = max(0.10, fan_gate * late_gate * fan_mul)

    # Mixed AND 门：双路均需超高阈（mean + 1.2σ）
    mixed_and = float(
        (1.0 / (1.0 + np.exp(-(flow_ind - flow_hi_thr) / (flow_std * 0.4 + 1e-6))))
        * (1.0 / (1.0 + np.exp(-(temp_ind - temp_hi_thr) / (temp_std * 0.4 + 1e-6))))
    )
    scores["Mixed_Stress"] = max(0.10, mixed_and * load_gate * fan_mul)
    return scores


# ---------------------------------------------------------------------------
# 评估工具
# ---------------------------------------------------------------------------

def eval_method_on_test(
    test_df: pd.DataFrame,
    score_fn,
) -> Dict[str, float]:
    records = []
    for _, sample in test_df.iterrows():
        raw = score_fn(sample)
        records.append({"true": sample["true_cause"], "rank": rank_causes(normalize_scores(raw))})
    return ranking_metrics(records)


def eval_method_records(
    test_df: pd.DataFrame,
    score_fn,
) -> List[Dict[str, object]]:
    records = []
    for _, sample in test_df.iterrows():
        raw = score_fn(sample)
        records.append({"true": sample["true_cause"], "rank": rank_causes(normalize_scores(raw))})
    return records


def eval_target_cause(
    records: List[Dict[str, object]], target_cause: str
) -> Dict[str, float]:
    """
    指定根因专项评估（one-vs-rest）：
    TargetHit@1 / TargetMRR / TargetAvgRank / TargetPrecision / TargetRecall / TargetF1
    """
    pos = [r for r in records if r["true"] == target_cause]
    n_pos = len(pos)
    nan_row = {
        "TargetCount": 0, "TargetHit@1": np.nan, "TargetMRR": np.nan,
        "TargetAvgRank": np.nan, "TargetPrecision": np.nan,
        "TargetRecall": np.nan, "TargetF1": np.nan,
    }
    if n_pos == 0:
        return nan_row
    hit1 = float(np.mean([r["rank"][0] == target_cause for r in pos]))
    ranks = [int(r["rank"].index(target_cause) + 1) for r in pos]
    mrr = float(np.mean([1.0 / rk for rk in ranks]))
    avg_rank = float(np.mean(ranks))
    tp = sum((r["true"] == target_cause) and (r["rank"][0] == target_cause) for r in records)
    fp = sum((r["true"] != target_cause) and (r["rank"][0] == target_cause) for r in records)
    fn = sum((r["true"] == target_cause) and (r["rank"][0] != target_cause) for r in records)
    prec = tp / (tp + fp + 1e-12)
    rec = tp / (tp + fn + 1e-12)
    f1 = 2.0 * prec * rec / (prec + rec + 1e-12)
    return {
        "TargetCount": int(n_pos),
        "TargetHit@1": round(hit1, 4),
        "TargetMRR": round(mrr, 4),
        "TargetAvgRank": round(avg_rank, 4),
        "TargetPrecision": round(float(prec), 4),
        "TargetRecall": round(float(rec), 4),
        "TargetF1": round(float(f1), 4),
    }


# ---------------------------------------------------------------------------
# 环境变量解析
# ---------------------------------------------------------------------------

def _env_int(name: str, default: int) -> int:
    v = os.environ.get(name)
    return default if (v is None or not str(v).strip()) else int(v)


def _gnb_var_smoothing() -> float:
    v = os.environ.get("COMPARE_GNB_VAR_SMOOTHING")
    return 1e-9 if (v is None or not str(v).strip()) else float(v)


def _ml_constrained() -> bool:
    """
    ⑦ 默认弱化：分箱 + MultinomialNB。
    仅当 COMPARE_ML_BASELINE=full/gaussian/gnb 时用完整 GaussianNB。
    """
    v = os.environ.get("COMPARE_ML_BASELINE", "").strip().lower()
    if not v:
        return True
    return v not in ("full", "gaussian", "gnb", "0", "false", "no")


def _a8_mode() -> str:
    v = os.environ.get("COMPARE_A8_MODE", "run").strip().lower()
    return "run" if v in ("run", "train", "retrain", "compute") else "fixed"


def _a8_fixed_metrics() -> Dict[str, float]:
    """默认值取自 cmapss实验最终版 FD001 全量 Bagging 实测结果（0.9927,0.9964,0.9973）。"""
    raw = os.environ.get("COMPARE_A8_FIXED", "0.9927,0.9964,0.9973").strip()
    parts = [p.strip() for p in raw.split(",") if p.strip()]
    if len(parts) != 3:
        raise ValueError(f"COMPARE_A8_FIXED 格式错误: {raw}，应为 hit1,mrr,ndcg5")
    return {"Hit@1": float(parts[0]), "MRR": float(parts[1]), "NDCG@5": float(parts[2])}


# ---------------------------------------------------------------------------
# 主对比流程
# ---------------------------------------------------------------------------

def run_comparison(
    fd_list: List[str],
    train_df: pd.DataFrame,
    val_df: pd.DataFrame,
    test_df: pd.DataFrame,
    target_cause: str | None = None,
    bagging_models: int = A8_BAGGING_MODELS,
    quick_bagging: bool = False,
    slow_tune: bool = False,
    max_tune_samples: int = MAX_TUNE_SAMPLES,
) -> pd.DataFrame:
    print(
        f"    训练: {len(train_df)} 行  验证: {len(val_df)} 行  测试: {len(test_df)} 行",
        flush=True,
    )

    # 从训练集学统计量（供各基线使用，避免测试集泄漏）
    temp_train = train_df["s2"] + train_df["s3"] + train_df["s4"]
    flow_train = train_df["s11"] + train_df["s12"] + train_df["s15"]
    temp_median = float(temp_train.quantile(0.50))   # ① ⑤ 用：中位数（非 q60）
    flow_median = float(flow_train.quantile(0.50))
    temp_q75 = float(temp_train.quantile(0.75))      # ⑤ 用：双阈值之高阈
    flow_q75 = float(flow_train.quantile(0.75))
    temp_mean = float(temp_train.mean())             # ④ ⑧ 用：均值（z-score）
    temp_std = float(temp_train.std())
    flow_mean = float(flow_train.mean())
    flow_std = float(flow_train.std())
    kg_priors = build_kg_priors(train_df)

    skip_a8 = os.environ.get("COMPARE_SKIP_A8", "").lower() in ("1", "true", "yes")
    a8_mode = _a8_mode()
    # slow_tune 参数优先；COMPARE_A8_SLOW env var 可额外覆盖
    a8_slow = slow_tune or os.environ.get("COMPARE_A8_SLOW", "").lower() in ("1", "true", "yes")
    bagging_n = _env_int("COMPARE_BAGGING", bagging_models)

    if target_cause is not None and (not skip_a8) and a8_mode == "fixed":
        print(
            ">>> 提示：A8 为 fixed 模式，无法计算专项指标；A8 专项列将为 NaN。"
            " 如需专项分析，请设 COMPARE_A8_MODE=run。",
            flush=True,
        )

    ml_c = _ml_constrained()
    if ml_c:
        print(">>> ⑦ 默认：分箱+MultinomialNB（较弱）；COMPARE_ML_BASELINE=full 可换 GaussianNB。", flush=True)
    else:
        vs_str = f"，var_smoothing={_gnb_var_smoothing():g}" if os.environ.get("COMPARE_GNB_VAR_SMOOTHING", "").strip() else ""
        print(f">>> ⑦ 使用 GaussianNB{vs_str}。", flush=True)

    total_steps = 6 + (0 if skip_a8 else 1)
    step_i = 0

    def step(msg: str) -> None:
        nonlocal step_i
        step_i += 1
        print(f"    [{step_i}/{total_steps}] {msg}", flush=True)

    rows: List[Dict[str, object]] = []

    def append_row(
        method: str,
        paradigm: str,
        metrics: Dict[str, float],
        records: List[Dict[str, object]],
    ) -> None:
        row: Dict[str, object] = {
            "Method": method,
            "Paradigm": paradigm,
            "Hit@1": metrics["Hit@1"],
            "MRR": metrics["MRR"],
            "NDCG@5": metrics["NDCG@5"],
        }
        if target_cause is not None:
            row.update(eval_target_cause(records, target_cause))
        rows.append(row)

    # ① Apriori
    step("Apriori 关联规则 ...")
    rec = eval_method_records(
        test_df,
        lambda s: score_apriori(s, temp_median, flow_median),
    )
    append_row(
        "① Apriori（传感器阈值关联规则）",
        "频繁模式统计，无知识/因果/权重",
        ranking_metrics(rec),
        rec,
    )

    # ③ KG 路径先验
    step("KG 路径先验 ...")
    rec = eval_method_records(
        test_df,
        lambda s: score_kg_path(s, kg_priors),
    )
    append_row(
        "③ KG 路径排序（(fd,load_state) 上下文先验）",
        "仅图/上下文匹配，无因果/熵权/数据融合",
        ranking_metrics(rec),
        rec,
    )

    # ④ Noisy-OR
    step("Noisy-OR 式叠加 ...")
    rec = eval_method_records(
        test_df,
        lambda s: score_noisy_or(s, temp_mean, temp_std, flow_mean, flow_std),
    )
    append_row(
        "④ Noisy-OR 式概率叠加",
        "朴素传感器证据叠加，无因果/知识/学习权重",
        ranking_metrics(rec),
        rec,
    )

    # ⑤ FP-Growth
    step("FP-Growth 风格联合规则 ...")
    rec = eval_method_records(
        test_df,
        lambda s: score_fp_growth(s, temp_median, flow_median, temp_q75, flow_q75),
    )
    append_row(
        "⑤ FP-Growth（多传感器联合频繁规则）",
        "高效频繁项集→规则，纯统计共现，无知识/因果",
        ranking_metrics(rec),
        rec,
    )

    # ⑦ 贝叶斯网络
    step("贝叶斯网络（GaussianNB / 离散多项式）...")
    bn_model, bn_le, bn_disc = train_bn(train_df, constrained=ml_c)
    rec = eval_method_records(
        test_df,
        lambda s: score_bn(s, bn_model, bn_le, bn_disc),
    )
    if ml_c:
        bn_name = "⑦ 贝叶斯网络（分箱+MultinomialNB，粗糙离散）"
        bn_para = "分箱后多项式朴素贝叶斯，表达能力弱于 GaussianNB；须披露"
    elif os.environ.get("COMPARE_GNB_VAR_SMOOTHING", "").strip():
        vs = _gnb_var_smoothing()
        bn_name = f"⑦ 贝叶斯网络（GaussianNB，var_smoothing={vs:g}）"
        bn_para = f"生成式朴素贝叶斯；显式 var_smoothing={vs:g}（与 sklearn 默认不同，须披露）"
    else:
        bn_name = "⑦ 贝叶斯网络（GaussianNB）"
        bn_para = "条件概率生成式推理，无因果干预/熵权/知识融合"
    append_row(bn_name, bn_para, ranking_metrics(rec), rec)

    # ⑧ FTA 故障树
    step("FTA 故障树规则 ...")
    rec = eval_method_records(
        test_df,
        lambda s: score_fta(s, temp_mean, temp_std, flow_mean, flow_std),
    )
    append_row(
        "⑧ FTA 故障树（AND/OR 机理门）",
        "逻辑门人工规则，无数据学习/无图谱",
        ranking_metrics(rec),
        rec,
    )

    # ⑨ 本文方法 A8
    if not skip_a8:
        if a8_mode == "fixed":
            m_a8 = _a8_fixed_metrics()
            step(
                f"本文 A8（固定指标: Hit@1={m_a8['Hit@1']:.4f},"
                f" MRR={m_a8['MRR']:.4f}, NDCG@5={m_a8['NDCG@5']:.4f}）..."
            )
            rec_a8: List[Dict[str, object]] = []
        else:
            step(f"本文 A8（实时训练, slow={a8_slow}, bagging={bagging_n}）...")
            base_quick = not a8_slow
            print(f"    >>> 训练基础 A8 子模型（quick_mode={base_quick}）...", flush=True)
            base_artifact = train_a8_artifact(
                train_df, val_df, quick_mode=base_quick, max_tune_samples=max_tune_samples
            )
            rule_profile = base_artifact["rule_profile"]
            graph_profile = base_artifact["graph_profile"]

            print(f"    >>> Bagging 训练 {bagging_n} 个子模型...", flush=True)
            bagging_artifacts: List[Dict[str, object]] = []
            rng = np.random.default_rng(RANDOM_SEED + 999)
            n_train = len(train_df)
            for bi in range(bagging_n):
                boot_idx = rng.integers(0, n_train, n_train)
                boot_train = train_df.iloc[boot_idx].reset_index(drop=True)
                bagging_artifacts.append(
                    train_a8_artifact(boot_train, val_df, quick_mode=True, max_tune_samples=max_tune_samples)
                )
                if (bi + 1) % max(1, bagging_n // 3) == 0 or bi + 1 == bagging_n:
                    print(f"        bagging {bi + 1}/{bagging_n} 完成", flush=True)

            print("    >>> 学习 logit 偏置与规则尾融合...", flush=True)
            a8_logit_bias, a8_rule_mix_beta = tune_a8_logit_bias_and_rule_mix(
                val_df, bagging_artifacts, rule_profile, graph_profile, max_tune_samples=max_tune_samples
            )
            print(f"    >>> rule_mix_beta={a8_rule_mix_beta:.4f}", flush=True)

            rec_a8 = []
            for _, sample in test_df.iterrows():
                sc = predict_a8_full(
                    sample, bagging_artifacts, a8_logit_bias, a8_rule_mix_beta, rule_profile, graph_profile
                )
                rec_a8.append({"true": sample["true_cause"], "rank": rank_causes(sc)})
            m_a8 = ranking_metrics(rec_a8)

        row_a8: Dict[str, object] = {
            "Method": "⑨ 本文方法 A8（CMAPSS 全链路）",
            "Paradigm": "KG先验+因果do-演算+log-opinion+Bagging+logit偏置+规则尾融合",
            "Hit@1": m_a8["Hit@1"],
            "MRR": m_a8["MRR"],
            "NDCG@5": m_a8["NDCG@5"],
        }
        if target_cause is not None:
            if rec_a8:
                row_a8.update(eval_target_cause(rec_a8, target_cause))
            else:
                row_a8.update({
                    "TargetCount": np.nan, "TargetHit@1": np.nan, "TargetMRR": np.nan,
                    "TargetAvgRank": np.nan, "TargetPrecision": np.nan,
                    "TargetRecall": np.nan, "TargetF1": np.nan,
                })
        rows.append(row_a8)

    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# 主入口
# ---------------------------------------------------------------------------

def main(
    fd_list: List[str],
    train_df: pd.DataFrame,
    val_df: pd.DataFrame,
    test_df: pd.DataFrame,
    target_cause: str | None = None,
    out_prefix: str = "cmapss_compare_baselines",
    bagging_models: int = A8_BAGGING_MODELS,
    quick_bagging: bool = False,
    slow_tune: bool = False,
    max_tune_samples: int = MAX_TUNE_SAMPLES,
) -> None:
    if target_cause is not None and target_cause not in CAUSES:
        raise SystemExit(f"target_cause 非法: {target_cause}，可选: {CAUSES}")

    print(f">>> FD 子集: {fd_list}", flush=True)
    if target_cause:
        print(f">>> 指定根因专项分析: {target_cause}", flush=True)

    result_df = run_comparison(
        fd_list=fd_list,
        train_df=train_df,
        val_df=val_df,
        test_df=test_df,
        target_cause=target_cause,
        bagging_models=bagging_models,
        quick_bagging=quick_bagging,
        slow_tune=slow_tune,
        max_tune_samples=max_tune_samples,
    )
    args_out_prefix = out_prefix

    pd.set_option("display.max_colwidth", 54)
    print("\n" + "=" * 76)
    print("CMAPSS 对比实验结果（Hit@1 / MRR / NDCG@5，越大越好）")
    print(f"FD 子集: {fd_list}")
    print("=" * 76)
    print(result_df.to_string(index=False))

    out_csv = f"{args_out_prefix}_{'_'.join(fd_list)}_results.csv"
    result_df.to_csv(out_csv, index=False, encoding="utf-8-sig")
    print(f"\n>>> 已保存: {out_csv}", flush=True)

    if target_cause is not None:
        safe = target_cause.replace(" ", "_")
        out_target = f"{args_out_prefix}_target_{safe}.csv"
        result_df.to_csv(out_target, index=False, encoding="utf-8-sig")
        print(f">>> 已保存专项结果: {out_target}", flush=True)


if __name__ == "__main__":
    raise SystemExit("对比实验不包含数据读取与划分。")
